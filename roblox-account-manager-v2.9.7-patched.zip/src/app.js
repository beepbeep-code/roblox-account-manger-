const $ = (s) => document.querySelector(s);
const statusEl = $("#status");
let remoteConfig = null;

let accounts = [];
let online = {};
let settings = {};
let onlineTimer = null;
let instanceTimer = null;
let isFocused = document.hasFocus();
let snowRunning = false;
let snowFrame = 0;
let snowParticles = [];
let snowCtx = null;
let snowW = 0;
let snowH = 0;

// Per-account runtime state (not persisted): status, errors, relaunch attempts, queue
const runtime = {};
let launchQueue = [];
let launchQueueBusy = false;
let savedPlaces = [];
let selectedAccounts = new Set();
let accountDrag = { active: false, anchor: null };
let refreshBusy = false;
let onlineBusy = false;

function ensureRuntime(name) {
  if (!runtime[name]) {
    runtime[name] = {
      status: "idle",
      lastError: "",
      relaunchAttempts: 0,
      nextAllowedAt: 0,
      lastLaunchAt: 0,
    };
  }
  return runtime[name];
}

function setAccountStatus(name, status, error = "") {
  const r = ensureRuntime(name);
  r.status = status;
  if (error) r.lastError = String(error).slice(0, 200);
  if (status === "in-game" || status === "online") {
    r.lastError = "";
    r.relaunchAttempts = 0;
  }
  renderLists();
}

function setStatus(text) {
  statusEl.textContent = text || "";
}

function placePreview(raw) {
  const m = String(raw || "").match(/(?:\/games\/|placeId=)?(\d{5,})/i);
  if (!m) return "Enter a place ID or game URL.";
  return "Place ID: " + m[1];
}

function setPage(page) {
  document.querySelectorAll(".nav").forEach((b) => b.classList.toggle("active", b.dataset.page === page));
  document.querySelectorAll(".page").forEach((p) => p.classList.toggle("active", p.id === "page-" + page));
  const titles = { home: "Dashboard", accounts: "Accounts", servers: "Servers", settings: "Settings", remote: "Remote access" };
  $("#pageTitle").textContent = titles[page] || "Dashboard";
}

document.querySelectorAll(".nav").forEach((btn) => {
  btn.addEventListener("click", () => setPage(btn.dataset.page));
});

function accountMarkup(name) {
  const info = online[name] || {};
  const r = ensureRuntime(name);
  let cls = "unk", label = "Checking";
  if (r.status === "launching") { cls = "busy"; label = "Launching…"; }
  else if (r.status === "relaunching") { cls = "busy"; label = "Relaunching…"; }
  else if (r.status === "queued") { cls = "busy"; label = "Queued"; }
  else if (r.status === "error") { cls = "err"; label = "Error"; }
  else if (info.online === true) { cls = "on"; label = "Online"; }
  else if (info.online === false) { cls = "off"; label = info.error === "session expired" ? "Expired" : "Offline"; }
  else if (info.error) { cls = "err"; label = "Error"; }

  const errTip = r.lastError ? ` title="${String(r.lastError).replace(/"/g, "&quot;")}"` : "";
  const attempts = r.relaunchAttempts > 0 ? `<span class="acct-meta">try ${r.relaunchAttempts}</span>` : "";
  const errLine = r.lastError ? `<span class="acct-error">${String(r.lastError).slice(0, 60)}</span>` : "";
  const checked = selectedAccounts.has(name) ? " checked" : "";
  const selected = selectedAccounts.has(name) ? " selected" : "";
  return `<div class="acct${selected}" data-account="${String(name).replace(/"/g, "&quot;")}" draggable="false"${errTip}>
    <input class="acct-check" type="checkbox" aria-label="Select ${String(name).replace(/"/g, "&quot;")}"${checked} />
    <span class="acct-main"><span class="name">${name}</span><span class="dot ${cls}">${label}</span></span>
    ${attempts}${errLine}
  </div>`;
}

function selectedVisibleNames() {
  const query = String($("#accountSearch")?.value || "").trim().toLowerCase();
  return accounts.filter((name) => name.toLowerCase().includes(query));
}

function syncSelectionToAccounts() {
  selectedAccounts = new Set([...selectedAccounts].filter((name) => accounts.includes(name)));
}

function getSelectedNames() {
  syncSelectionToAccounts();
  return [...selectedAccounts];
}

function setToggleMixed(el, values) {
  if (!el) return;
  const uniq = [...new Set(values.map((v) => !!v))];
  if (uniq.length > 1) {
    el.checked = false;
    el.indeterminate = true;
    el.dataset.mixed = "1";
  } else {
    el.indeterminate = false;
    el.dataset.mixed = "0";
    el.checked = !!uniq[0];
  }
}

function updateSelectionUi() {
  const names = getSelectedNames();
  const n = names.length;
  const label = $("#selectionLabel");
  const sub = $("#selectionSub");
  const chips = $("#selectionChips");
  if (label) label.textContent = n === 0 ? "No accounts selected" : n === 1 ? `Editing ${names[0]}` : `Editing ${n} accounts`;
  if (sub) {
    sub.textContent = n === 0
      ? "Select accounts on the left (checkboxes, Ctrl-click, Shift-click, or drag). Changes below apply to every selected account."
      : n === 1
        ? "Edit settings for this account, then Save."
        : `Save will write these values to all ${n} selected accounts.`;
  }
  if (chips) {
    if (!n) chips.innerHTML = "";
    else if (n <= 8) {
      chips.innerHTML = names.map((name) =>
        `<span class="sel-chip" data-remove="${String(name).replace(/"/g, "&quot;")}">${name}<button type="button" class="sel-chip-x" title="Remove from selection">×</button></span>`
      ).join("");
    } else {
      chips.innerHTML = `<span class="sel-chip muted">${n} selected</span>`;
    }
  }

  const disabled = n === 0;
  for (const id of ["#btnSaveCfg", "#btnJoinFromAccount", "#btnEnableSelectedRelaunch", "#btnStopSelectedRelaunch", "#btnApplyDelaySelected", "#btnDelete"]) {
    const btn = $(id);
    if (btn) btn.disabled = disabled;
  }
  if ($("#btnSaveCfg")) $("#btnSaveCfg").textContent = n > 1 ? `Save to ${n} selected` : "Save to selected";
  if ($("#btnJoinFromAccount")) $("#btnJoinFromAccount").textContent = n > 1 ? `▶ Launch ${n} selected` : "▶ Launch selected";
  if ($("#btnDelete")) $("#btnDelete").textContent = n > 1 ? `Delete ${n} selected` : "Delete selected";
}

function paintSelectionClasses() {
  document.querySelectorAll("#accountList .acct, #accountListHome .acct").forEach((el) => {
    const name = el.dataset.account;
    const on = selectedAccounts.has(name);
    el.classList.toggle("selected", on);
    const check = el.querySelector(".acct-check");
    if (check) check.checked = on;
  });
  updateSelectionUi();
}

async function loadCfgForSelection() {
  const names = getSelectedNames();
  updateSelectionUi();
  if (!names.length) {
    if ($("#cfgAuto")) { $("#cfgAuto").checked = false; $("#cfgAuto").indeterminate = false; $("#cfgAuto").dataset.mixed = "0"; }
    if ($("#cfgServerShuffle")) { $("#cfgServerShuffle").checked = false; $("#cfgServerShuffle").indeterminate = false; $("#cfgServerShuffle").dataset.mixed = "0"; }
    if ($("#cfgPlace")) $("#cfgPlace").value = "";
    if ($("#cfgDelay")) $("#cfgDelay").value = 15;
    if ($("#cfgPlaceHint")) $("#cfgPlaceHint").textContent = "";
    return;
  }

  const configs = [];
  for (const name of names) {
    try { configs.push(await window.api.getAccountConfig(name)); }
    catch { configs.push({ autoRelaunch: false, serverShuffle: false, placeId: "", relaunchDelaySec: 15 }); }
  }

  setToggleMixed($("#cfgAuto"), configs.map((c) => c.autoRelaunch));
  setToggleMixed($("#cfgServerShuffle"), configs.map((c) => c.serverShuffle));

  const places = [...new Set(configs.map((c) => String(c.placeId || "").trim()))];
  const delays = [...new Set(configs.map((c) => Math.max(1, Number(c.relaunchDelaySec) || 15)))];
  if (places.length === 1) {
    $("#cfgPlace").value = places[0];
    if ($("#cfgPlaceHint")) $("#cfgPlaceHint").textContent = "";
  } else {
    $("#cfgPlace").value = "";
    if ($("#cfgPlaceHint")) $("#cfgPlaceHint").textContent = `Mixed Place IDs across ${names.length} accounts — enter a value to set all, or leave blank to keep each.`;
  }
  if (delays.length === 1) {
    $("#cfgDelay").value = delays[0];
  } else {
    $("#cfgDelay").value = delays[0] || 15;
  }

  if ($("#cfgAccount") && names.length === 1) {
    $("#cfgAccount").value = names[0];
  }
}

function visibleAccountElements() {
  return [...document.querySelectorAll("#accountList .acct")];
}

function renderLists() {
  syncSelectionToAccounts();
  const filtered = selectedVisibleNames();
  const list = $("#accountList");
  if (list) {
    list.innerHTML = filtered.length
      ? filtered.map(accountMarkup).join("")
      : `<div class="empty">${accounts.length ? "No matching accounts." : "No accounts yet.<br>Use + Add account to create a session."}</div>`;
  }
  const home = $("#accountListHome");
  if (home) {
    home.innerHTML = accounts.length
      ? accounts.slice(0, 8).map(accountMarkup).join("")
      : `<div class="empty">No saved accounts.</div>`;
  }
  updateSelectionUi();
}

// Event delegation for account list — avoids rebinding on every render (which broke multi-select).
function setupAccountListEvents() {
  const list = $("#accountList");
  if (!list || list.dataset.bound === "1") return;
  list.dataset.bound = "1";

  list.addEventListener("click", async (e) => {
    const row = e.target.closest(".acct");
    if (!row || !list.contains(row)) return;
    if (e.target.closest(".acct-check")) return;
    const name = row.dataset.account;
    const visible = visibleAccountElements();
    const idx = visible.indexOf(row);
    if (e.shiftKey && accountDrag.anchor !== null) {
      const a = Math.min(accountDrag.anchor, idx), b = Math.max(accountDrag.anchor, idx);
      visible.slice(a, b + 1).forEach((x) => selectedAccounts.add(x.dataset.account));
    } else if (e.ctrlKey || e.metaKey) {
      selectedAccounts.has(name) ? selectedAccounts.delete(name) : selectedAccounts.add(name);
      accountDrag.anchor = idx;
    } else {
      selectedAccounts.clear();
      selectedAccounts.add(name);
      accountDrag.anchor = idx;
    }
    paintSelectionClasses();
    await loadCfgForSelection();
    setStatus(selectedAccounts.size > 1 ? `Selected ${selectedAccounts.size} accounts` : `Selected ${name}`);
  });

  list.addEventListener("pointerdown", (e) => {
    if (e.button !== 0) return;
    const row = e.target.closest(".acct");
    if (!row || e.target.closest(".acct-check")) return;
    const visible = visibleAccountElements();
    const idx = visible.indexOf(row);
    accountDrag.active = true;
    accountDrag.anchor = idx;
    if (!(e.ctrlKey || e.metaKey || e.shiftKey)) {
      selectedAccounts.clear();
      selectedAccounts.add(row.dataset.account);
      paintSelectionClasses();
    }
  });

  list.addEventListener("pointerover", (e) => {
    if (!accountDrag.active || accountDrag.anchor === null) return;
    const row = e.target.closest(".acct");
    if (!row || !list.contains(row)) return;
    const visible = visibleAccountElements();
    const idx = visible.indexOf(row);
    if (idx < 0) return;
    const a = Math.min(accountDrag.anchor, idx), b = Math.max(accountDrag.anchor, idx);
    selectedAccounts = new Set(visible.slice(a, b + 1).map((x) => x.dataset.account));
    paintSelectionClasses();
  });

  list.addEventListener("change", async (e) => {
    if (!e.target.classList.contains("acct-check")) return;
    const row = e.target.closest(".acct");
    if (!row) return;
    const name = row.dataset.account;
    if (e.target.checked) selectedAccounts.add(name); else selectedAccounts.delete(name);
    paintSelectionClasses();
    await loadCfgForSelection();
  });
}

document.addEventListener("pointerup", async () => {
  if (accountDrag.active) {
    accountDrag.active = false;
    await loadCfgForSelection();
  }
});

$("#btnSelectAll")?.addEventListener("click", async () => {
  selectedAccounts = new Set(selectedVisibleNames());
  paintSelectionClasses();
  await loadCfgForSelection();
  setStatus(`Selected ${selectedAccounts.size} accounts`);
});
$("#btnClearSelection")?.addEventListener("click", async () => {
  selectedAccounts.clear();
  paintSelectionClasses();
  await loadCfgForSelection();
  setStatus("Selection cleared");
});

$("#selectionChips")?.addEventListener("click", async (e) => {
  const chip = e.target.closest(".sel-chip");
  if (!chip || !chip.dataset.remove) return;
  selectedAccounts.delete(chip.dataset.remove);
  paintSelectionClasses();
  await loadCfgForSelection();
});

// Clear indeterminate state when user clicks a mixed toggle
["#cfgAuto", "#cfgServerShuffle"].forEach((sel) => {
  $(sel)?.addEventListener("click", () => {
    const el = $(sel);
    if (el) { el.indeterminate = false; el.dataset.mixed = "0"; }
  });
});

async function saveDashboardPlace(account, placeId) {
  if (!account) return;
  const cfg = await window.api.getAccountConfig(account);
  await window.api.saveAccountConfig(account, {
    ...cfg,
    placeId: String(placeId || "").trim(),
  });
}

$("#accountSelect").addEventListener("change", async (e) => {
  const account = e.target.value;
  if (!account) {
    $("#placeId").value = "";
    $("#urlPreview").textContent = "Select an account first.";
    return;
  }
  await loadCfg(account);
});

$("#placeId").addEventListener("change", async (e) => {
  const account = $("#accountSelect").value;
  if (!account) return;
  try {
    await saveDashboardPlace(account, e.target.value);
    setStatus("Place ID saved for " + account);
  } catch (err) {
    setStatus("Could not save Place ID");
  }
});

async function refreshAccounts() {
  if (refreshBusy) return;
  refreshBusy = true;
  try {
    const previous = $("#accountSelect")?.value;
    const hadSelection = selectedAccounts.size > 0;
    accounts = await window.api.listAccounts();
    syncSelectionToAccounts();
    for (const sel of ["#accountSelect", "#cfgAccount"]) {
      const el = $(sel);
      if (!el) continue;
      const prev = el.value || previous;
      el.innerHTML = accounts.length
        ? accounts.map((a) => `<option value="${a.replace(/"/g, "&quot;")}">${a}</option>`).join("")
        : `<option value="">No accounts</option>`;
      if (accounts.includes(prev)) el.value = prev;
    }
    const serverSel = $("#serverAccount");
    if (serverSel) {
      const serverPrev = serverSel.value;
      serverSel.innerHTML = accounts.length ? accounts.map(a => `<option value="${a.replace(/"/g, "&quot;")}">${a}</option>`).join("") : `<option value="">No accounts</option>`;
      if (accounts.includes(serverPrev)) serverSel.value = serverPrev;
      else if (accounts.length) serverSel.value = accounts[0];
    }
    renderLists();
    if (accounts.length) {
      const selected = accounts.includes($("#accountSelect").value) ? $("#accountSelect").value : accounts[0];
      $("#accountSelect").value = selected;
      if (!hadSelection && !selectedAccounts.size) {
        // Do not auto-select on periodic refresh — only when list was empty
      }
    }
    updateSelectionUi();
  } catch (e) {
    setStatus("Account refresh failed");
  } finally { refreshBusy = false; }
}

async function pollOnline() {
  if (!accounts.length || onlineBusy) return;
  onlineBusy = true;
  try {
    $("#pollState").textContent = "Active";
    online = await window.api.checkOnline(accounts);
    renderLists();
  } catch (e) {
    setStatus("Online check failed");
  } finally { onlineBusy = false; }
}

function scheduleOnline() {
  if (onlineTimer) clearInterval(onlineTimer);
  const sec = Math.max(5, Number(settings.onlineIntervalSec || 12));
  onlineTimer = setInterval(() => pollOnline(), sec * 1000);
  $("#pollState").textContent = "Active";
  pollOnline();
}

async function loadSettings() {
  settings = await window.api.getSettings();
  $("#cfgMax").value = settings.maxInstances ?? 15;
  $("#cfgLaunchDelay").value = settings.launcherDelaySec ?? 20;
  $("#cfgGap").value = settings.multiJoinGapSec ?? 15;
  $("#cfgOnlineInt").value = settings.onlineIntervalSec ?? 12;
  $("#cfgMulti").checked = !!settings.multiInstance;
  $("#cfgDash").value = settings.dashboardUrl || "";
  $("#cfgStartWindows").checked = !!settings.startWithWindows;
  if ($("#cfgCloseToTray")) $("#cfgCloseToTray").checked = settings.closeToTray !== false;
  if ($("#cfgAutoMinimizeRoblox")) $("#cfgAutoMinimizeRoblox").checked = !!settings.autoMinimizeRoblox;
  if ($("#cfgMaxRelaunch")) $("#cfgMaxRelaunch").value = settings.maxRelaunchAttempts ?? 5;
  if ($("#cfgRelaunchCooldown")) $("#cfgRelaunchCooldown").value = settings.relaunchCooldownSec ?? 300;
  if ($("#cfgFpsCap")) $("#cfgFpsCap").value = settings.framerateCap ?? -1;
  const ss = settings.serverShuffle || {};
  $("#cfgShuffleEnabled").checked = !!ss.enabled;
  $("#cfgShuffleHours").value = ss.intervalHours ?? 2;
  if ($("#cfgShuffleRegion")) $("#cfgShuffleRegion").value = ss.region && ss.region !== "Any" ? ss.region : "";
  if ($("#cfgShuffleMaxPing")) $("#cfgShuffleMaxPing").value = ss.maxPing ?? 250;
  $("#multiStatus").textContent = settings.multiInstance ? "Status: enabled" : "Status: off";
  try {
    const cap = await window.api.getFramerateCap();
    if ($("#cfgFpsCap") && Number.isFinite(cap)) $("#cfgFpsCap").value = cap;
  } catch {}
  try {
    savedPlaces = await window.api.getSavedPlaces();
    renderSavedPlaces();
  } catch { savedPlaces = []; }
  try {
    const ver = await window.api.getAppVersion();
    if ($("#appVersionLabel")) $("#appVersionLabel").textContent = "v" + (ver.version || "2.9.0");
    if ($(".version")) $(".version").textContent = "v" + (ver.version || "2.9.0") + " • desktop";
  } catch {}
  scheduleOnline();
}

function renderSavedPlaces() {
  const el = $("#savedPlacesList");
  if (!el) return;
  if (!savedPlaces.length) {
    el.innerHTML = `<div class="empty">No saved places yet.</div>`;
    return;
  }
  el.innerHTML = savedPlaces.map((p) =>
    `<button type="button" class="place-chip" data-place="${p}">${p}<span class="place-remove" data-remove="${p}" title="Remove">×</span></button>`
  ).join("");
  el.querySelectorAll(".place-chip").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      if (e.target.dataset.remove) return;
      const place = btn.dataset.place;
      if ($("#placeId")) $("#placeId").value = place;
      if ($("#cfgPlace")) $("#cfgPlace").value = place;
      if ($("#urlPreview")) $("#urlPreview").textContent = placePreview(place);
      setStatus("Place " + place + " selected");
    });
  });
  el.querySelectorAll("[data-remove]").forEach((btn) => {
    btn.addEventListener("click", async (e) => {
      e.stopPropagation();
      const place = btn.dataset.remove;
      savedPlaces = savedPlaces.filter((p) => p !== place);
      await window.api.saveSavedPlaces(savedPlaces);
      renderSavedPlaces();
    });
  });
}

async function addSavedPlace(raw) {
  const m = String(raw || "").match(/(\d{5,})/);
  if (!m) return;
  const place = m[1];
  if (!savedPlaces.includes(place)) {
    savedPlaces = [place, ...savedPlaces].slice(0, 50);
    await window.api.saveSavedPlaces(savedPlaces);
    renderSavedPlaces();
  }
}

async function runLaunchQueue() {
  if (launchQueueBusy) return;
  launchQueueBusy = true;
  try {
    while (launchQueue.length) {
      const job = launchQueue[0];
      setAccountStatus(job.name, "launching");
      updateLaunchQueueUi();
      try {
        const n = await window.api.countRoblox();
        if (n >= (settings.maxInstances || 15)) {
          setAccountStatus(job.name, "error", "Max instances reached");
          launchQueue.shift();
          continue;
        }
        await window.api.joinGame(job.name, job.place);
        const r = ensureRuntime(job.name);
        r.lastLaunchAt = Date.now();
        setAccountStatus(job.name, "in-game");
        setStatus("Launched " + job.name);
      } catch (e) {
        setAccountStatus(job.name, "error", e?.message || "Launch failed");
        setStatus("Launch failed: " + (e?.message || "unknown"));
      }
      launchQueue.shift();
      updateLaunchQueueUi();
      if (launchQueue.length) {
        const gap = Math.max(0, Number(settings.multiJoinGapSec || 15)) * 1000;
        const delay = Math.max(gap, (settings.launcherDelaySec || 0) * 1000);
        if (delay) await new Promise((r) => setTimeout(r, delay));
      }
    }
  } finally {
    launchQueueBusy = false;
    updateLaunchQueueUi();
  }
}

function enqueueLaunch(name, place) {
  if (!name || !place) return;
  if (launchQueue.some((j) => j.name === name)) {
    setStatus(name + " already in queue");
    return;
  }
  launchQueue.push({ name, place: String(place).trim() });
  setAccountStatus(name, "queued");
  updateLaunchQueueUi();
  runLaunchQueue();
}

function updateLaunchQueueUi() {
  const el = $("#launchQueueState");
  if (!el) return;
  if (!launchQueue.length && !launchQueueBusy) {
    el.textContent = "Queue empty";
    return;
  }
  const total = launchQueue.length + (launchQueueBusy ? 0 : 0);
  const current = launchQueue[0];
  if (current) {
    el.textContent = `Launching ${current.name}… (${launchQueue.length} left)`;
  } else {
    el.textContent = total ? `${total} in queue` : "Queue empty";
  }
}

async function loadCfg(name) {
  if (!name) return;
  const cfg = await window.api.getAccountConfig(name);
  $("#cfgAuto").checked = !!cfg.autoRelaunch;
  $("#cfgServerShuffle").checked = !!cfg.serverShuffle;
  $("#cfgPlace").value = cfg.placeId || "";
  $("#placeId").value = cfg.placeId || "";
  $("#urlPreview").textContent = placePreview(cfg.placeId || "");
  $("#cfgDelay").value = cfg.relaunchDelaySec ?? 15;
}

$("#cfgAccount")?.addEventListener("change", async (e) => {
  const name = e.target.value;
  if (!name) return;
  selectedAccounts = new Set([name]);
  paintSelectionClasses();
  await loadCfgForSelection();
});
$("#accountSearch")?.addEventListener("input", renderLists);

async function saveAccountCfg() {
  const names = getSelectedNames();
  if (!names.length) {
    alert("Select one or more accounts first");
    return;
  }

  const placeRaw = $("#cfgPlace").value.trim();
  const delay = Math.max(1, Number($("#cfgDelay").value) || 15);
  const autoEl = $("#cfgAuto");
  const shuffleEl = $("#cfgServerShuffle");
  const autoMixed = autoEl?.dataset.mixed === "1" && autoEl.indeterminate;
  const shuffleMixed = shuffleEl?.dataset.mixed === "1" && shuffleEl.indeterminate;

  let saved = 0;
  for (const name of names) {
    const existing = await window.api.getAccountConfig(name);
    const cfg = {
      autoRelaunch: autoMixed ? !!existing.autoRelaunch : !!autoEl?.checked,
      serverShuffle: shuffleMixed ? !!existing.serverShuffle : !!shuffleEl?.checked,
      // Blank place with mixed values keeps each account's existing place
      placeId: placeRaw || (existing.placeId || ""),
      relaunchDelaySec: delay,
    };
    await window.api.saveAccountConfig(name, cfg);
    saved += 1;
  }

  // Sync dashboard place if the focused home account was in the selection
  const dash = $("#accountSelect")?.value;
  if (dash && names.includes(dash) && placeRaw) {
    $("#placeId").value = placeRaw;
    $("#urlPreview").textContent = placePreview(placeRaw);
  }

  setStatus(saved > 1 ? `Saved settings to ${saved} accounts` : `Saved ${names[0]}`);
  await loadCfgForSelection();
}

$("#btnSaveCfg").addEventListener("click", saveAccountCfg);

$("#btnApplyDelayAll")?.addEventListener("click", async () => {
  const delay = Math.max(1, Number($("#cfgDelay").value) || 15);
  try {
    const result = await window.api.applyRelaunchDelayAll(delay);
    setStatus(`Relaunch delay set to ${result.delay}s on ${result.count} account(s)`);
    await loadCfgForSelection();
  } catch (e) {
    setStatus("Failed to apply delay to all accounts");
  }
});

$("#btnApplyDelaySelected")?.addEventListener("click", async () => {
  const names = getSelectedNames();
  if (!names.length) return alert("Select one or more accounts first");
  const delay = Math.max(1, Number($("#cfgDelay").value) || 15);
  for (const name of names) {
    const existing = await window.api.getAccountConfig(name);
    await window.api.saveAccountConfig(name, { ...existing, relaunchDelaySec: delay });
  }
  setStatus(`Relaunch delay set to ${delay}s on ${names.length} selected account(s)`);
  await loadCfgForSelection();
});

$("#btnEnableSelectedRelaunch")?.addEventListener("click", async () => {
  const names = getSelectedNames();
  if (!names.length) return alert("Select one or more accounts first");
  for (const name of names) {
    const existing = await window.api.getAccountConfig(name);
    await window.api.saveAccountConfig(name, { ...existing, autoRelaunch: true });
  }
  setStatus(`Auto-relaunch enabled on ${names.length} selected account(s)`);
  await loadCfgForSelection();
});

$("#btnStopSelectedRelaunch")?.addEventListener("click", async () => {
  const names = getSelectedNames();
  if (!names.length) return alert("Select one or more accounts first");
  for (const name of names) {
    const existing = await window.api.getAccountConfig(name);
    await window.api.saveAccountConfig(name, { ...existing, autoRelaunch: false });
  }
  setStatus(`Auto-relaunch disabled on ${names.length} selected account(s)`);
  await loadCfgForSelection();
});

$("#btnJoinFromAccount").addEventListener("click", async () => {
  const names = getSelectedNames();
  if (!names.length) return alert("Select one or more accounts first");
  const formPlace = $("#cfgPlace").value.trim();
  try {
    // Persist current form values first so launches use what you see
    await saveAccountCfg();
    let queued = 0;
    for (const name of names) {
      const cfg = await window.api.getAccountConfig(name);
      const place = formPlace || String(cfg.placeId || "").trim();
      if (!place) {
        setStatus(`${name} has no Place ID — skipped`);
        continue;
      }
      await addSavedPlace(place);
      enqueueLaunch(name, place);
      queued += 1;
    }
    if (!queued) alert("None of the selected accounts have a Place ID.");
    else setStatus(`Queued ${queued} account(s)`);
  } catch (e) {
    setStatus("Join failed");
    alert(e.message);
  }
});

$("#cfgPlace").addEventListener("keydown", (e) => {
  if (e.key === "Enter") saveAccountCfg();
});
$("#cfgDelay").addEventListener("keydown", (e) => {
  if (e.key === "Enter") saveAccountCfg();
});

$("#btnSaveSettings").addEventListener("click", async () => {
  const regionRaw = ($("#cfgShuffleRegion")?.value || "").trim();
  settings = await window.api.saveSettings({
    maxInstances: Math.max(1, Number($("#cfgMax").value) || 15),
    launcherDelaySec: Math.max(0, Number($("#cfgLaunchDelay").value) || 20),
    multiJoinGapSec: Math.max(1, Number($("#cfgGap").value) || 15),
    onlineIntervalSec: Number($("#cfgOnlineInt").value) || 12,
    dashboardUrl: $("#cfgDash").value.trim(),
    startWithWindows: $("#cfgStartWindows").checked,
    closeToTray: $("#cfgCloseToTray") ? $("#cfgCloseToTray").checked : true,
    autoMinimizeRoblox: $("#cfgAutoMinimizeRoblox") ? $("#cfgAutoMinimizeRoblox").checked : false,
    maxRelaunchAttempts: Math.max(1, Number($("#cfgMaxRelaunch")?.value) || 5),
    relaunchCooldownSec: Math.max(30, Number($("#cfgRelaunchCooldown")?.value) || 300),
    framerateCap: Number($("#cfgFpsCap")?.value ?? -1),
    serverShuffle: {
      enabled: $("#cfgShuffleEnabled").checked,
      intervalHours: Math.max(0.25, Number($("#cfgShuffleHours").value) || 2),
      minPing: 0,
      maxPing: Math.max(0, Number($("#cfgShuffleMaxPing")?.value) || 250),
      region: regionRaw || "Any",
    },
  });
  await window.api.serverShuffleSettings(settings.serverShuffle);
  scheduleOnline();
  setStatus("Settings saved");
});

$("#btnApplyFps")?.addEventListener("click", async () => {
  try {
    const cap = Number($("#cfgFpsCap")?.value ?? -1);
    const result = await window.api.setFramerateCap(cap);
    setStatus(`FPS cap set to ${result.value}. ${result.note}`);
  } catch (e) {
    alert(e?.message || "Could not update FramerateCap");
  }
});

$("#btnMinimizeAll")?.addEventListener("click", async () => {
  try {
    const result = await window.api.minimizeAllRoblox();
    setStatus(result.ok ? `Minimized ${result.count} Roblox window(s)` : (result.message || "Minimize failed"));
  } catch (e) {
    setStatus("Minimize failed");
  }
});

$("#btnStopAllRelaunch")?.addEventListener("click", async () => {
  try {
    const result = await window.api.applyAutoRelaunchAll(false);
    await loadCfgForSelection();
    setStatus(`Auto-relaunch disabled on ${result.count} account(s)`);
  } catch {
    setStatus("Could not disable Auto-relaunch");
  }
});

$("#btnEnableAllRelaunch")?.addEventListener("click", async () => {
  try {
    const result = await window.api.applyAutoRelaunchAll(true);
    await loadCfgForSelection();
    setStatus(`Auto-relaunch enabled on ${result.count} account(s)`);
  } catch {
    setStatus("Could not enable Auto-relaunch");
  }
});

$("#btnExportAccounts")?.addEventListener("click", async () => {
  try {
    const data = await window.api.exportAccounts();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "ram-accounts-export.json";
    a.click();
    URL.revokeObjectURL(a.href);
    setStatus("Exported account config (no cookies)");
  } catch {
    setStatus("Export failed");
  }
});

$("#btnImportAccounts")?.addEventListener("click", () => {
  $("#importFileInput")?.click();
});

async function refreshDataPathHint() {
  try {
    const info = await window.api.getDataPaths();
    const el = $("#dataPathHint");
    if (!el) return;
    const enc = info.encrypted ? "OS-encrypted (DPAPI)" : "obfuscated (fallback)";
    el.textContent = `Sessions: ${info.sessions} · ${enc}`;
    el.title = info.dataRoot;
  } catch {
    if ($("#dataPathHint")) $("#dataPathHint").textContent = "Secure AppData storage";
  }
}

$("#btnImportLegacy")?.addEventListener("click", async () => {
  try {
    setStatus("Select your older RAM folder…");
    const result = await window.api.importLegacyFolder();
    if (result?.cancelled) {
      setStatus("Import cancelled");
      return;
    }
    if (!result?.ok) {
      alert(result?.error || "Import failed");
      return;
    }
    await refreshAccounts();
    await loadSettings();
    await refreshDataPathHint();
    setStatus(`Imported ${result.sessions || 0} session(s), ${result.accounts || 0} account(s) from old folder`);
    alert(`Import complete.\n\nSessions migrated: ${result.sessions || 0}\nAccounts added/updated: ${result.accounts || 0}\n\nSessions are now encrypted in AppData. You should not need to log in again.`);
  } catch (e) {
    alert(e?.message || "Import failed");
    setStatus("Import failed");
  }
});

$("#importFileInput")?.addEventListener("change", async (e) => {
  const file = e.target.files?.[0];
  if (!file) return;
  try {
    const text = await file.text();
    const payload = JSON.parse(text);
    const result = await window.api.importAccounts(payload);
    await refreshAccounts();
    setStatus(`Import done: ${result.added} added, ${result.updated} updated`);
  } catch (err) {
    alert("Import failed: " + (err?.message || "invalid file"));
  }
  e.target.value = "";
});

$("#btnAddSavedPlace")?.addEventListener("click", async () => {
  const raw = $("#newSavedPlace")?.value || $("#placeId")?.value || "";
  await addSavedPlace(raw);
  if ($("#newSavedPlace")) $("#newSavedPlace").value = "";
});

$("#btnCheckUpdates")?.addEventListener("click", async () => {
  try {
    const ver = await window.api.getAppVersion();
    await window.api.checkForUpdates();
    setStatus("Opened releases page (current v" + ver.version + ")");
  } catch {
    setStatus("Could not open update page");
  }
});

window.api.onTrayAction?.(async (action) => {
  if (action === "pause-all-relaunch") {
    try {
      const result = await window.api.applyAutoRelaunchAll(false);
      setStatus(`Tray: Auto-relaunch off for ${result.count} account(s)`);
    } catch {}
  }
});

function openAddAccountModal() {
  $("#addAccountModal").hidden = false;
  $("#newAccountName").value = "";
  setTimeout(() => $("#newAccountName").focus(), 0);
}
function closeAddAccountModal() {
  $("#addAccountModal").hidden = true;
}
async function addAccount() {
  const name = $("#newAccountName").value.trim();
  if (!name) { $("#newAccountName").focus(); return; }
  closeAddAccountModal();
  setStatus("Opening Roblox login…");
  $("#btnAdd").disabled = true;
  $("#btnAddHome").disabled = true;
  $("#btnConfirmAdd").disabled = true;
  try {
    await window.api.addAccount(name);
    await refreshAccounts();
    setStatus("Saved " + name);
  } catch (e) {
    setStatus("Add failed");
    alert(e?.message || "Could not add account.");
  } finally {
    $("#btnAdd").disabled = false;
    $("#btnAddHome").disabled = false;
    $("#btnConfirmAdd").disabled = false;
  }
}
$("#btnAdd").addEventListener("click", openAddAccountModal);
$("#btnAddHero").addEventListener("click", openAddAccountModal);
$("#btnAddHome").addEventListener("click", openAddAccountModal);
$("#btnConfirmAdd").addEventListener("click", addAccount);
$("#btnCancelAdd").addEventListener("click", closeAddAccountModal);
$("#btnCloseAdd").addEventListener("click", closeAddAccountModal);
$("#newAccountName").addEventListener("keydown", (e) => {
  if (e.key === "Enter") addAccount();
  if (e.key === "Escape") closeAddAccountModal();
});
$("#addAccountModal").addEventListener("click", (e) => {
  if (e.target.id === "addAccountModal") closeAddAccountModal();
});

$("#btnDelete").addEventListener("click", async () => {
  const names = getSelectedNames();
  if (!names.length) return alert("Select one or more accounts first");
  const msg = names.length === 1
    ? `Delete ${names[0]}?`
    : `Delete ${names.length} selected accounts?\n\n${names.slice(0, 12).join(", ")}${names.length > 12 ? "…" : ""}`;
  if (!confirm(msg)) return;
  for (const name of names) {
    await window.api.deleteAccount(name);
    selectedAccounts.delete(name);
  }
  await refreshAccounts();
  await loadCfgForSelection();
  setStatus(names.length > 1 ? `Deleted ${names.length} accounts` : `Deleted ${names[0]}`);
});

$("#btnJoin").addEventListener("click", async () => {
  const account = $("#accountSelect").value;
  const place = $("#placeId").value.trim();
  if (!account) return alert("Select an account");
  if (!place) return alert("Enter a place ID");
  try { await saveDashboardPlace(account, place); } catch {}
  await addSavedPlace(place);
  enqueueLaunch(account, place);
});

async function launchSavedAccounts() {
  const targets = [];
  for (const name of accounts) {
    const cfg = await window.api.getAccountConfig(name);
    if ((cfg.placeId || "").trim()) targets.push([name, cfg.placeId.trim()]);
  }
  if (!targets.length) return alert("No accounts have a saved Place ID yet.");
  for (const [name, place] of targets) enqueueLaunch(name, place);
  setStatus("Queued " + targets.length + " saved account(s)");
}
$("#btnMulti")?.addEventListener("click", launchSavedAccounts);
$("#btnLaunchSaved")?.addEventListener("click", launchSavedAccounts);

$("#btnHome").addEventListener("click", async () => {
  const account = $("#accountSelect").value;
  if (!account) return;
  try { await window.api.openHome(account); }
  catch (e) { alert(e.message); }
});

$("#btnCloseAll").addEventListener("click", async () => {
  if (!confirm("Force-close all Roblox processes?")) return;
  await window.api.closeAllRoblox();
  setStatus("Closed Roblox processes");
  tickInstances();
});

$("#cfgMulti").addEventListener("change", async (e) => {
  if (e.target.checked) {
    try {
      const running = await window.api.countRoblox();
      if (running > 0) {
        const proceed = confirm(
          `Close all Roblox clients before enabling multi-instance.\n\n${running} Roblox process(es) are still running.\n\nClose them now and enable?`
        );
        if (!proceed) {
          e.target.checked = false;
          $("#multiStatus").textContent = "Status: off — close Roblox first";
          return;
        }
        await window.api.closeAllRoblox();
        await new Promise((r) => setTimeout(r, 600));
      }
    } catch {}
    const res = await window.api.multiEnable();
    $("#multiStatus").textContent = res.ok ? "Status: active" : ("Status: failed — " + (res.message || "error"));
    if (res.ok) {
      await window.api.saveSettings({ multiInstance: true });
      setStatus(res.message || "Multi-instance enabled");
    } else {
      e.target.checked = false;
      alert(res.message || "Could not enable multi-instance. Close all Roblox clients and try again.");
    }
  } else {
    await window.api.multiDisable();
    $("#multiStatus").textContent = "Status: off";
    await window.api.saveSettings({ multiInstance: false });
    setStatus("Multi-instance disabled");
  }
});

let serverRows = [];
function syncServerPlace() {
  const account = $("#serverAccount").value;
  if (!account) return;
  const cfg = accounts.includes(account) ? window.api.getAccountConfig(account) : null;
  Promise.resolve(cfg).then(c => { if (c && c.placeId && !$("#serverPlace").value.trim()) $("#serverPlace").value = c.placeId; });
}
async function refreshServers() {
  const account = $("#serverAccount").value;
  const place = $("#serverPlace").value.trim();
  if (!account) return alert("Select an account first");
  if (!place) return alert("Enter a Place ID first");
  $("#serverHint").textContent = "Loading servers and checking region/ping…";
  $("#serverList").innerHTML = '<div class="empty">Loading servers…</div>';
  try {
    serverRows = await window.api.getServers(account, place);
    renderServers();
    $("#serverHint").textContent = "Servers already assigned to another account are excluded from random selection.";
  } catch (e) {
    $("#serverList").innerHTML = '<div class="empty">Could not load servers.</div>';
    $("#serverHint").textContent = e.message || "Server lookup failed.";
  }
}
function renderServers() {
  const region = $("#serverRegion").value.trim().toLowerCase();
  const maxPing = Number($("#serverMaxPing").value) || 9999;
  const rows = serverRows.filter(s => (region === "" || String(s.region || "Unknown").toLowerCase().includes(region)) && (s.ping == null || s.ping <= maxPing));
  $("#serverCount").textContent = `${rows.length} servers`;
  $("#serverList").innerHTML = rows.length ? rows.map(s => `<div class="server-row"><span>${s.playing}/${s.maxPlayers}</span><span>${s.region || "Unknown"}${s.country ? `, ${s.country}` : ""}</span><span>${s.ping == null ? "—" : `${s.ping} ms`}</span><button class="mini-btn join-server" data-job="${s.id}">Join</button></div>`).join("") : '<div class="empty">No servers match those filters.</div>';
  document.querySelectorAll(".join-server").forEach(b => b.addEventListener("click", async () => {
    const account = $("#serverAccount").value, place = $("#serverPlace").value.trim();
    try { await window.api.joinGame(account, place, b.dataset.job); setStatus("Join sent"); } catch (e) { alert(e.message); }
  }));
}
$("#serverAccount").addEventListener("change", syncServerPlace);
$("#serverRegion").addEventListener("input", renderServers);
$("#serverMaxPing").addEventListener("input", renderServers);
$("#btnRefreshServers").addEventListener("click", refreshServers);
$("#btnShuffleOnce").addEventListener("click", async () => {
  const account = $("#serverAccount").value, place = $("#serverPlace").value.trim();
  if (!account || !place) return alert("Select an account and enter a Place ID first");
  try {
    const chosen = await window.api.shuffleServer(account, place, { region: $("#serverRegion").value.trim() || "Any", maxPing: Number($("#serverMaxPing").value) || 250 });
    await window.api.closeAccount(account);
    await new Promise(r => setTimeout(r, 1000));
    await window.api.joinGame(account, place, chosen.id);
    setStatus(`Shuffled to ${chosen.region || "a random server"}`);
  } catch (e) { alert(e.message); }
});
$("#btnShuffleAccounts").addEventListener("click", async () => {
  let done = 0;
  for (const account of accounts) {
    const cfg = await window.api.getAccountConfig(account);
    if (!cfg.serverShuffle || !cfg.placeId) continue;
    try {
      const chosen = await window.api.shuffleServer(account, cfg.placeId, { region: $("#serverRegion").value.trim() || "Any", maxPing: Number($("#serverMaxPing").value) || 250 });
      await window.api.closeAccount(account);
      await new Promise(r => setTimeout(r, 1000));
      await window.api.joinGame(account, cfg.placeId, chosen.id);
      done++;
    } catch {}
  }
  setStatus(`Shuffled ${done} accounts`);
});

$("#btnOpenDash").addEventListener("click", () => {
  let url = $("#cfgDash").value.trim();
  if (!url) return alert("Set a URL first");
  if (!/^https?:/i.test(url)) url = "https://" + url;
  window.api.saveSettings({ dashboardUrl: url });
  window.api.openExternal(url);
});

$("#btnRefresh").addEventListener("click", async () => {
  await refreshAccounts();
  setStatus("Refreshed");
});

async function tickInstances() {
  try {
    const n = await window.api.countRoblox();
    $("#instBadge").textContent = n + " instances";
    $("#processCount").textContent = n;
    $("#processTrack").style.width = Math.min(100, (n / Math.max(1, settings.maxInstances || 5)) * 100) + "%";
  } catch {}
}

function setupLowPowerState() {
  const update = () => {
    isFocused = document.hasFocus() && !document.hidden;
    // Decorative snow still pauses when unfocused to save GPU.
    // Auto-relaunch monitoring does NOT pause (see autoReconnectOfflineAccounts).
    $("#snowState").textContent = isFocused ? "Running" : "Paused (UI only)";
    $("#pollState").textContent = isFocused ? "Active" : "Background (relaunch on)";
    if (isFocused) {
      startSnow();
      if (accounts.length) pollOnline();
    } else {
      stopSnow();
    }
  };
  window.addEventListener("focus", update, { passive: true });
  window.addEventListener("blur", update, { passive: true });
  document.addEventListener("visibilitychange", update, { passive: true });
  update();
}

// Discord invite link in the sidebar
$("#discordLink")?.addEventListener("click", (e) => {
  e.preventDefault();
  window.api.openExternal("https://discord.gg/TR8RvUf67N");
});

function initSnow() {
  snowCtx = $("#snowCanvas").getContext("2d", { alpha: true, desynchronized: true });
  resizeSnow();
  window.addEventListener("resize", resizeSnow, { passive: true });

  // Small, bounded particle count keeps the visual subtle and cheap.
  const count = Math.min(70, Math.max(28, Math.floor((window.innerWidth * window.innerHeight) / 18000)));
  snowParticles = Array.from({ length: count }, () => ({
    x: Math.random() * snowW,
    y: Math.random() * snowH,
    r: Math.random() * 1.8 + .35,
    vy: Math.random() * .45 + .18,
    vx: (Math.random() - .5) * .18,
    drift: Math.random() * Math.PI * 2,
    alpha: Math.random() * .55 + .15,
  }));
}

function resizeSnow() {
  if (!snowCtx) return;
  const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
  snowW = window.innerWidth;
  snowH = window.innerHeight;
  $("#snowCanvas").width = Math.floor(snowW * dpr);
  $("#snowCanvas").height = Math.floor(snowH * dpr);
  snowCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
}

function startSnow() {
  if (snowRunning || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  snowRunning = true;
  snowFrame = requestAnimationFrame(drawSnow);
}

function stopSnow() {
  snowRunning = false;
  if (snowFrame) cancelAnimationFrame(snowFrame);
  snowFrame = 0;
  if (snowCtx) snowCtx.clearRect(0, 0, snowW, snowH);
}

function drawSnow(time) {
  if (!snowRunning || document.hidden || !document.hasFocus()) {
    stopSnow();
    return;
  }

  snowCtx.clearRect(0, 0, snowW, snowH);
  const t = time * 0.00015;
  for (const p of snowParticles) {
    p.y += p.vy;
    p.x += p.vx + Math.sin(t + p.drift) * .055;
    if (p.y > snowH + 5) { p.y = -5; p.x = Math.random() * snowW; }
    if (p.x < -5) p.x = snowW + 5;
    if (p.x > snowW + 5) p.x = -5;

    snowCtx.globalAlpha = p.alpha;
    snowCtx.fillStyle = "#eaf5ff";
    snowCtx.beginPath();
    snowCtx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
    snowCtx.fill();
  }
  snowCtx.globalAlpha = 1;
  snowFrame = requestAnimationFrame(drawSnow);
}


async function loadRemoteConfig() {
  remoteConfig = await window.api.remoteGetConfig();
  $("#remoteName").value = remoteConfig.deviceName || "My PC";
  $("#remoteRelay").value = remoteConfig.relayUrl || "https://aureon-collective.xyz";
  $("#remoteDeviceId").textContent = remoteConfig.deviceId || "—";
  $("#secureStorageBadge").textContent = remoteConfig.secureStorage ? "OS encrypted" : "Unavailable";
  $("#secureStorageBadge").classList.toggle("bad", !remoteConfig.secureStorage);
  updateRemoteState(
    remoteConfig.connected
      ? "Connected"
      : (remoteConfig.paired
        ? (remoteConfig.lastError ? `Paired · ${remoteConfig.lastError}` : "Paired · connecting")
        : "Not paired"),
    remoteConfig.connected
  );
}
function updateRemoteState(text, active) {
  const el = $("#remoteState");
  el.innerHTML = `<span class="status-dot"></span><span>${text}</span>`;
  el.classList.toggle("active", !!active);
}

$("#btnPairRemote").addEventListener("click", async () => {
  const code = $("#remotePairCode").value.trim().toUpperCase();
  if (!code) return alert("Enter the pairing code shown by the website dashboard.");
  try {
    $("#btnPairRemote").disabled = true;
    setStatus("Pairing this PC…");
    remoteConfig = await window.api.remotePair({
      code,
      relayUrl: $("#remoteRelay").value.trim(),
      deviceName: $("#remoteName").value.trim() || "My PC",
    });
    $("#remoteDeviceId").textContent = remoteConfig.deviceId || "—";
    $("#remotePairCode").value = "";
    updateRemoteState("Paired · connecting", false);
    setStatus("PC paired. Connecting securely…");
  } catch (e) {
    alert(e.message || "Could not pair this PC.");
    setStatus("Pairing failed");
  } finally {
    $("#btnPairRemote").disabled = false;
  }
});

$("#btnUnpairRemote").addEventListener("click", async () => {
  if (!remoteConfig?.paired) return;
  if (!confirm("Unpair this PC from the remote dashboard? You will need a new pairing code to reconnect.")) return;
  await window.api.remoteUnpair();
  remoteConfig = await window.api.remoteGetConfig();
  $("#remoteDeviceId").textContent = "—";
  updateRemoteState("Not paired", false);
  setStatus("Remote access unpaired");
});

async function autoConnectConfiguredAccounts() {
  const targets = [];
  for (const name of accounts) {
    try {
      const cfg = await window.api.getAccountConfig(name);
      if (cfg.autoRelaunch && String(cfg.placeId || "").trim()) {
        targets.push([name, String(cfg.placeId).trim(), Math.max(1, Number(cfg.relaunchDelaySec) || 15)]);
      }
    } catch {}
  }
  if (!targets.length) return;
  setStatus("Connecting selected accounts…");
  for (let i = 0; i < targets.length; i++) {
    const [name, place, delay] = targets[i];
    try {
      const n = await window.api.countRoblox();
      if (n >= (settings.maxInstances || 15)) break;
      await new Promise((r) => setTimeout(r, i === 0 ? 1200 : Math.max(1000, delay * 1000)));
      await window.api.joinGame(name, place);
    } catch (e) {
      setStatus("Auto-relaunch failed: " + e.message);
    }
  }
  setStatus("Ready");
}

let autoReconnectBusy = false;
async function autoReconnectOfflineAccounts() {
  // Runs even when the window is unfocused/minimized. Only real process exit /
  // offline status triggers a relaunch — never mere loss of focus.
  if (autoReconnectBusy || !accounts.length) return;
  autoReconnectBusy = true;
  try {
    const currentOnline = await window.api.checkOnline(accounts);
    online = currentOnline;
    const maxAttempts = Math.max(1, Number(settings.maxRelaunchAttempts) || 5);
    const cooldownMs = Math.max(30, Number(settings.relaunchCooldownSec) || 300) * 1000;
    for (const name of accounts) {
      const cfg = await window.api.getAccountConfig(name);
      if (!cfg.autoRelaunch || !String(cfg.placeId || "").trim()) continue;
      if (currentOnline[name]?.online === true) {
        setAccountStatus(name, "online");
        continue;
      }
      const running = await window.api.accountProcessRunning(name);
      if (running) continue;
      const r = ensureRuntime(name);
      if (Date.now() < (r.nextAllowedAt || 0)) continue;
      if (r.relaunchAttempts >= maxAttempts) {
        r.nextAllowedAt = Date.now() + cooldownMs;
        r.relaunchAttempts = 0;
        setAccountStatus(name, "error", `Max relaunch attempts (${maxAttempts}) — cooling down`);
        continue;
      }
      const n = await window.api.countRoblox();
      if (n >= (settings.maxInstances || 15)) break;
      const delay = Math.max(1, Number(cfg.relaunchDelaySec) || 15);
      r.relaunchAttempts += 1;
      setAccountStatus(name, "relaunching");
      setStatus(`Reconnecting ${name} (attempt ${r.relaunchAttempts}/${maxAttempts})…`);
      await new Promise((res) => setTimeout(res, delay * 1000));
      try {
        await window.api.joinGame(name, cfg.placeId);
        r.lastLaunchAt = Date.now();
        setAccountStatus(name, "in-game");
      } catch (e) {
        setAccountStatus(name, "error", e?.message || "Relaunch failed");
      }
    }
    renderLists();
  } catch {}
  finally {
    autoReconnectBusy = false;
  }
}


// ── UI theme ───────────────────────────────────────────────────
// Dark is the default. The choice is stored locally in the renderer only.
function applyTheme(theme) {
  const value = theme === "light" ? "light" : "dark";
  document.documentElement.dataset.theme = value;
  document.documentElement.style.colorScheme = value;
  const btn = $("#btnTheme");
  if (btn) {
    btn.textContent = value === "dark" ? "☼" : "☾";
    btn.title = value === "dark" ? "Switch to light mode" : "Switch to dark mode";
    btn.setAttribute("aria-label", btn.title);
  }
}
function initTheme() {
  let saved = "dark";
  try { saved = localStorage.getItem("ram-theme") || "dark"; } catch {}
  applyTheme(saved);
  $("#btnTheme")?.addEventListener("click", () => {
    const next = document.documentElement.dataset.theme === "light" ? "dark" : "light";
    applyTheme(next);
    try { localStorage.setItem("ram-theme", next); } catch {}
  });
}
initTheme();

(async function init() {
  // Clean UI mode: no decorative snow renderer.
  setupAccountListEvents();
  await loadSettings();
  try { await refreshDataPathHint(); } catch {}
  await refreshAccounts();
  await loadRemoteConfig();
  // Auto-relaunch is opt-in per account. Monitoring continues while the app is
  // running (including minimized/unfocused). Only real disconnects trigger relaunch.
  await autoConnectConfiguredAccounts();
  setInterval(() => autoReconnectOfflineAccounts(), Math.max(10, Number(settings.onlineIntervalSec || 12)) * 1000);
  // Refresh account list occasionally without wiping multi-select every few seconds
  setInterval(() => refreshAccounts(), 15000);
  setInterval(async () => {
    if (!settings.autoMinimizeRoblox) return;
    try { await window.api.minimizeAllRoblox(); } catch {}
  }, 5000);
  setInterval(async () => {
    try {
      remoteConfig = await window.api.remoteGetConfig();
      updateRemoteState(
        remoteConfig.connected
          ? "Connected"
          : (remoteConfig.enabled
            ? (remoteConfig.lastError ? `Connecting · ${remoteConfig.lastError}` : "Connecting")
            : "Disabled"),
        remoteConfig.connected
      );
    } catch {}
  }, 2500);

  // Instance badge can keep updating in the background so the pill stays accurate.
  instanceTimer = setInterval(() => {
    tickInstances();
  }, 3000);

  tickInstances();
  setStatus("Ready");
})();
