const { app, BrowserWindow, ipcMain, shell, Tray, Menu, nativeImage, dialog } = require("electron");
const path = require("path");
const fs = require("fs");
const os = require("os");
const { pathToFileURL } = require("url");
const crypto = require("crypto");
const { safeStorage } = require("electron");
const { execFile } = require("child_process");
const WebSocket = require("ws");

const ROOT = path.join(__dirname, "..");

// Portable/legacy layout (next to the app folder from older builds)
const LEGACY_SESSIONS = path.join(ROOT, "sessions");
const LEGACY_ACCOUNTS_DIR = path.join(ROOT, "accounts");
const LEGACY_SECURE = path.join(ROOT, "secure");

// Secure long-term storage under the current Windows user profile.
// %APPDATA%\RobloxAccountManager — survives replacing the app zip.
const DATA_ROOT = process.env.APPDATA
  ? path.join(process.env.APPDATA, "RobloxAccountManager")
  : path.join(os.homedir(), ".roblox-account-manager");
const SESSIONS = path.join(DATA_ROOT, "sessions");
const ACCOUNTS_DIR = path.join(DATA_ROOT, "accounts");
const SECURE = path.join(DATA_ROOT, "secure");

for (const d of [SESSIONS, ACCOUNTS_DIR, SECURE]) {
  if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
}

const SETTINGS_PATH = path.join(ACCOUNTS_DIR, "settings.json");
const ACCOUNTS_PATH = path.join(ACCOUNTS_DIR, "accounts.json");
const REMOTE_KEY_PATH = path.join(SECURE, "remote-master-key.bin");
const REMOTE_IDENTITY_PATH = path.join(SECURE, "remote-agent-identity.bin");
const MIGRATION_FLAG = path.join(DATA_ROOT, ".migrated-from-legacy");

function loadJson(p, fallback) {
  try {
    if (fs.existsSync(p)) return JSON.parse(fs.readFileSync(p, "utf8"));
  } catch {}
  return fallback;
}
function saveJson(p, data) {
  fs.writeFileSync(p, JSON.stringify(data, null, 2));
}

function safeAccountKey(name) {
  return String(name).replace(/[^\w\-]/g, "_");
}

function sessionEncPath(name) {
  return path.join(SESSIONS, safeAccountKey(name) + ".session");
}

function sessionLegacyPath(name) {
  return path.join(LEGACY_SESSIONS, safeAccountKey(name) + ".json");
}

/** Encrypt session JSON at rest with OS DPAPI / Keychain via Electron safeStorage. */
function saveSessionState(name, state) {
  const json = JSON.stringify(state);
  const dest = sessionEncPath(name);
  try {
    if (safeStorage.isEncryptionAvailable()) {
      fs.writeFileSync(dest, safeStorage.encryptString(json), { mode: 0o600 });
    } else {
      // Fallback: still not plain .ROBLOSECURITY filename; weak obfuscation only.
      const buf = Buffer.from(json, "utf8");
      const mask = crypto.createHash("sha256").update("ram-session-" + os.hostname()).digest();
      const out = Buffer.alloc(buf.length);
      for (let i = 0; i < buf.length; i++) out[i] = buf[i] ^ mask[i % mask.length];
      fs.writeFileSync(dest, Buffer.concat([Buffer.from("RAM1"), out]), { mode: 0o600 });
    }
  } catch (e) {
    throw new Error("Could not save encrypted session: " + (e.message || e));
  }
  // Remove any leftover plaintext copy next to the app
  try {
    const legacy = sessionLegacyPath(name);
    if (fs.existsSync(legacy)) fs.unlinkSync(legacy);
  } catch {}
}

/** Load session state object (Playwright storageState shape). */
function loadSessionState(name) {
  const enc = sessionEncPath(name);
  if (fs.existsSync(enc)) {
    try {
      const raw = fs.readFileSync(enc);
      if (safeStorage.isEncryptionAvailable()) {
        try {
          return JSON.parse(safeStorage.decryptString(raw));
        } catch {
          // Might be the XOR fallback format
        }
      }
      if (raw.length > 4 && raw.slice(0, 4).toString() === "RAM1") {
        const body = raw.slice(4);
        const mask = crypto.createHash("sha256").update("ram-session-" + os.hostname()).digest();
        const out = Buffer.alloc(body.length);
        for (let i = 0; i < body.length; i++) out[i] = body[i] ^ mask[i % mask.length];
        return JSON.parse(out.toString("utf8"));
      }
      // Last resort: treat as plaintext JSON (very old)
      return JSON.parse(raw.toString("utf8"));
    } catch (e) {
      throw new Error("Session file is corrupted or cannot be decrypted for " + name);
    }
  }
  // Legacy plaintext next to the app
  const legacy = sessionLegacyPath(name);
  if (fs.existsSync(legacy)) {
    try {
      const state = JSON.parse(fs.readFileSync(legacy, "utf8"));
      try { saveSessionState(name, state); } catch {}
      return state;
    } catch {
      throw new Error("Legacy session file is unreadable for " + name);
    }
  }
  return null;
}

function deleteSessionState(name) {
  for (const p of [sessionEncPath(name), sessionLegacyPath(name)]) {
    try { if (fs.existsSync(p)) fs.unlinkSync(p); } catch {}
  }
}

/**
 * One-time migration: copy accounts/settings/sessions from the old portable
 * folders (next to the zip) into %APPDATA%\RobloxAccountManager and encrypt sessions.
 */
function migrateLegacyData() {
  const report = { accounts: 0, sessions: 0, settings: false, from: [] };
  try {
    // accounts.json
    const legacyAccounts = path.join(LEGACY_ACCOUNTS_DIR, "accounts.json");
    if (fs.existsSync(legacyAccounts)) {
      const incoming = loadJson(legacyAccounts, { accounts: {} });
      const current = loadJson(ACCOUNTS_PATH, { accounts: {} });
      current.accounts = current.accounts || {};
      for (const [name, cfg] of Object.entries(incoming.accounts || {})) {
        if (!current.accounts[name]) {
          current.accounts[name] = cfg;
          report.accounts += 1;
        } else {
          current.accounts[name] = { ...cfg, ...current.accounts[name] };
        }
      }
      saveJson(ACCOUNTS_PATH, current);
      report.from.push(legacyAccounts);
    }
    // settings.json
    const legacySettings = path.join(LEGACY_ACCOUNTS_DIR, "settings.json");
    if (fs.existsSync(legacySettings) && !fs.existsSync(SETTINGS_PATH)) {
      try {
        fs.copyFileSync(legacySettings, SETTINGS_PATH);
        report.settings = true;
        report.from.push(legacySettings);
      } catch {}
    }
    // remote key
    const legacyKey = path.join(LEGACY_SECURE, "remote-master-key.bin");
    if (fs.existsSync(legacyKey) && !fs.existsSync(REMOTE_KEY_PATH)) {
      try { fs.copyFileSync(legacyKey, REMOTE_KEY_PATH); } catch {}
    }
    const legacyDevice = path.join(LEGACY_SECURE, "device-id");
    const newDevice = path.join(SECURE, "device-id");
    if (fs.existsSync(legacyDevice) && !fs.existsSync(newDevice)) {
      try { fs.copyFileSync(legacyDevice, newDevice); } catch {}
    }
    // plaintext session JSON files
    if (fs.existsSync(LEGACY_SESSIONS)) {
      for (const file of fs.readdirSync(LEGACY_SESSIONS)) {
        if (!file.endsWith(".json")) continue;
        const name = file.replace(/\.json$/i, "");
        const full = path.join(LEGACY_SESSIONS, file);
        try {
          if (fs.existsSync(sessionEncPath(name))) continue;
          const state = JSON.parse(fs.readFileSync(full, "utf8"));
          if (!state || !Array.isArray(state.cookies)) continue;
          saveSessionState(name, state);
          report.sessions += 1;
          report.from.push(full);
        } catch {}
      }
    }
    // Also pick up any sessions already listed in accounts.json that still live as legacy files
    const data = loadJson(ACCOUNTS_PATH, { accounts: {} });
    for (const name of Object.keys(data.accounts || {})) {
      if (fs.existsSync(sessionEncPath(name))) continue;
      const legacy = sessionLegacyPath(name);
      if (!fs.existsSync(legacy)) continue;
      try {
        const state = JSON.parse(fs.readFileSync(legacy, "utf8"));
        saveSessionState(name, state);
        report.sessions += 1;
      } catch {}
    }
    try { fs.writeFileSync(MIGRATION_FLAG, JSON.stringify({ at: new Date().toISOString(), ...report }, null, 2)); } catch {}
  } catch (e) {
    console.error("Legacy migration failed:", e);
  }
  return report;
}


/** Import sessions + accounts from an older RAM folder (must contain sessions/ and/or accounts/). */
function importFromLegacyRoot(legacyRoot) {
  const report = { accounts: 0, sessions: 0, settings: false, path: legacyRoot };
  if (!legacyRoot || !fs.existsSync(legacyRoot)) throw new Error("Folder not found");

  const legacyAccountsDir = path.join(legacyRoot, "accounts");
  const legacySessionsDir = path.join(legacyRoot, "sessions");
  const legacySecureDir = path.join(legacyRoot, "secure");

  // Some builds stored files directly in the chosen folder
  const accountsFileCandidates = [
    path.join(legacyAccountsDir, "accounts.json"),
    path.join(legacyRoot, "accounts.json"),
  ];
  for (const legacyAccounts of accountsFileCandidates) {
    if (!fs.existsSync(legacyAccounts)) continue;
    const incoming = loadJson(legacyAccounts, { accounts: {} });
    const current = loadJson(ACCOUNTS_PATH, { accounts: {} });
    current.accounts = current.accounts || {};
    for (const [name, cfg] of Object.entries(incoming.accounts || {})) {
      if (!current.accounts[name]) {
        current.accounts[name] = cfg;
        report.accounts += 1;
      } else {
        current.accounts[name] = { ...current.accounts[name], ...cfg };
      }
    }
    saveJson(ACCOUNTS_PATH, current);
    break;
  }

  const settingsCandidates = [
    path.join(legacyAccountsDir, "settings.json"),
    path.join(legacyRoot, "settings.json"),
  ];
  for (const legacySettings of settingsCandidates) {
    if (fs.existsSync(legacySettings) && !fs.existsSync(SETTINGS_PATH)) {
      try { fs.copyFileSync(legacySettings, SETTINGS_PATH); report.settings = true; } catch {}
      break;
    }
  }

  const sessionDirs = [legacySessionsDir, path.join(legacyRoot, "session"), legacyRoot];
  const seen = new Set();
  for (const dir of sessionDirs) {
    if (!fs.existsSync(dir) || !fs.statSync(dir).isDirectory()) continue;
    for (const file of fs.readdirSync(dir)) {
      if (!file.toLowerCase().endsWith(".json")) continue;
      const full = path.join(dir, file);
      // skip accounts.json/settings.json if someone selected a mixed folder
      if (/^(accounts|settings)\.json$/i.test(file)) continue;
      const name = file.replace(/\.json$/i, "");
      if (seen.has(name) || fs.existsSync(sessionEncPath(name))) continue;
      try {
        const state = JSON.parse(fs.readFileSync(full, "utf8"));
        if (!state || !Array.isArray(state.cookies)) continue;
        const hasCookie = state.cookies.some((c) => c.name === ".ROBLOSECURITY" && c.value);
        if (!hasCookie) continue;
        saveSessionState(name, state);
        // Ensure account exists in accounts.json
        const data = loadJson(ACCOUNTS_PATH, { accounts: {} });
        data.accounts = data.accounts || {};
        if (!data.accounts[name]) {
          data.accounts[name] = { autoRelaunch: false, serverShuffle: false, placeId: "", relaunchDelaySec: 15 };
          saveJson(ACCOUNTS_PATH, data);
          report.accounts += 1;
        }
        seen.add(name);
        report.sessions += 1;
      } catch {}
    }
  }

  const legacyKey = path.join(legacySecureDir, "remote-master-key.bin");
  if (fs.existsSync(legacyKey) && !fs.existsSync(REMOTE_KEY_PATH)) {
    try { fs.copyFileSync(legacyKey, REMOTE_KEY_PATH); } catch {}
  }
  return report;
}


const APP_VERSION = "2.9.7";
const UPDATE_CHECK_URL = "https://github.com/EliteLevelSoftware/Elite-Level-Account-Manager/releases/latest";

function defaultSettings() {
  return {
    maxInstances: 15,
    launcherDelaySec: 20,
    multiJoinGapSec: 15,
    onlineIntervalSec: 12,
    multiInstance: true,
    dashboardUrl: "",
    remote: { enabled: false, relayUrl: "", deviceName: "My PC" },
    serverShuffle: { enabled: false, intervalHours: 2, minPing: 0, maxPing: 250, region: "Any" },
    startWithWindows: false,
    closeToTray: true,
    autoMinimizeRoblox: false,
    maxRelaunchAttempts: 5,
    relaunchCooldownSec: 300,
    framerateCap: -1,
    savedPlaces: [],
  };
}

let mainWindow = null;
let tray = null;
let isQuitting = false;
let mutexHandles = []; // kept in process for multi-instance
let remoteBridge = null;
const remoteReplay = new Map();

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 920,
    height: 640,
    minWidth: 800,
    minHeight: 520,
    backgroundColor: "#030507",
    title: "Roblox Account Manager",
    // Keep timers/IPC alive while minimized or unfocused so Auto-Relaunch can monitor.
    backgroundThrottling: false,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      backgroundThrottling: false,
    },
  });
  mainWindow.loadFile(path.join(ROOT, "src", "index.html"));
  mainWindow.setMenuBarVisibility(false);

  mainWindow.on("close", (e) => {
    const settings = { ...defaultSettings(), ...loadJson(SETTINGS_PATH, {}) };
    if (!isQuitting && settings.closeToTray) {
      e.preventDefault();
      mainWindow.hide();
    }
  });
}

function buildTray() {
  if (tray) return;
  // 16x16 simple dark square as a minimal tray icon (no external asset required)
  const icon = nativeImage.createEmpty();
  try {
    const size = 16;
    const buf = Buffer.alloc(size * size * 4);
    for (let i = 0; i < size * size; i++) {
      buf[i * 4] = 40; buf[i * 4 + 1] = 48; buf[i * 4 + 2] = 60; buf[i * 4 + 3] = 255;
    }
    // Draw a small accent pixel block
    for (let y = 4; y < 12; y++) {
      for (let x = 4; x < 12; x++) {
        const i = (y * size + x) * 4;
        buf[i] = 111; buf[i + 1] = 170; buf[i + 2] = 255; buf[i + 3] = 255;
      }
    }
    tray = new Tray(nativeImage.createFromBuffer(buf, { width: size, height: size }));
  } catch {
    tray = new Tray(nativeImage.createEmpty());
  }
  tray.setToolTip("Roblox Account Manager");
  const contextMenu = Menu.buildFromTemplate([
    { label: "Open", click: () => { if (mainWindow) { mainWindow.show(); mainWindow.focus(); } } },
    { label: "Pause all Auto-relaunch", click: () => { if (mainWindow) mainWindow.webContents.send("tray-action", "pause-all-relaunch"); } },
    { label: "Close all Roblox", click: () => { closeAllRobloxProcesses(); } },
    { type: "separator" },
    { label: "Quit", click: () => { isQuitting = true; app.quit(); } },
  ]);
  tray.setContextMenu(contextMenu);
  tray.on("double-click", () => { if (mainWindow) { mainWindow.show(); mainWindow.focus(); } });
}

function getRobloxSettingsPath() {
  const local = process.env.LOCALAPPDATA || path.join(os.homedir(), "AppData", "Local");
  return path.join(local, "Roblox", "GlobalBasicSettings_13.xml");
}

function readFramerateCap() {
  try {
    const p = getRobloxSettingsPath();
    if (!fs.existsSync(p)) return -1;
    const xml = fs.readFileSync(p, "utf8");
    const m = xml.match(/<int\s+name="FramerateCap">\s*(-?\d+)\s*<\/int>/i);
    return m ? Number(m[1]) : -1;
  } catch { return -1; }
}

function writeFramerateCap(cap) {
  const value = Number(cap);
  const n = Number.isFinite(value) ? Math.floor(value) : -1;
  const p = getRobloxSettingsPath();
  if (!fs.existsSync(p)) {
    throw new Error("Roblox settings file not found. Launch Roblox once so it creates GlobalBasicSettings_13.xml.");
  }
  let xml = fs.readFileSync(p, "utf8");
  if (/<int\s+name="FramerateCap">\s*-?\d+\s*<\/int>/i.test(xml)) {
    xml = xml.replace(/<int\s+name="FramerateCap">\s*-?\d+\s*<\/int>/i, `<int name="FramerateCap">${n}</int>`);
  } else if (/<\/Properties>/i.test(xml)) {
    xml = xml.replace(/<\/Properties>/i, `  <int name="FramerateCap">${n}</int>\n</Properties>`);
  } else {
    throw new Error("Could not locate FramerateCap in GlobalBasicSettings_13.xml");
  }
  fs.writeFileSync(p, xml, "utf8");
  return n;
}

function minimizeAllRobloxWindows() {
  if (process.platform !== "win32") return { ok: false, message: "Windows only" };
  return new Promise((resolve) => {
    const script = `
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class Win {
  [DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
}
"@
$SW_MINIMIZE = 6
$count = 0
Get-Process RobloxPlayerBeta -ErrorAction SilentlyContinue | ForEach-Object {
  $h = $_.MainWindowHandle
  if ($h -ne [IntPtr]::Zero -and [Win]::IsWindowVisible($h)) {
    [Win]::ShowWindowAsync($h, $SW_MINIMIZE) | Out-Null
    $count++
  }
}
Write-Output $count
`;
    execFile("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", script], { windowsHide: true, timeout: 8000 }, (err, stdout) => {
      if (err) return resolve({ ok: false, message: err.message, count: 0 });
      resolve({ ok: true, count: Number(String(stdout).trim()) || 0 });
    });
  });
}



// ── secure remote agent ───────────────────────────────────────
// The desktop app is the security anchor for remote control. It makes an
// outbound WSS connection only; it never opens a listening port. Pairing
// creates a local Ed25519 identity and the relay stores only the public key.
const REMOTE_PROTOCOL_VERSION = 1;
const REMOTE_COMMAND_WINDOW_MS = 60 * 1000;
const REMOTE_STATE_INTERVAL_MS = 15 * 1000;
const REMOTE_HEARTBEAT_INTERVAL_MS = 20 * 1000;
const REMOTE_ALLOWED_COMMANDS = new Set([
  "GET_STATUS", "GET_ACCOUNTS", "GET_INSTANCES", "GET_ACTIVITY",
  "SET_SETTING", "SET_ACCOUNT_CONFIG", "LAUNCH_ACCOUNT", "MULTI_JOIN",
  "ENABLE_MULTI_INSTANCE", "DISABLE_MULTI_INSTANCE", "CLOSE_ROBLOX", "OPEN_ROBLOX_HOME",
]);

function canonicalRemote(value) {
  if (value === null || typeof value !== "object") return JSON.stringify(value ?? null);
  if (Array.isArray(value)) return "[" + value.map(canonicalRemote).join(",") + "]";
  return "{" + Object.keys(value).sort().map((k) => JSON.stringify(k) + ":" + canonicalRemote(value[k])).join(",") + "}";
}

function getDeviceId() {
  try {
    const identity = getRemoteIdentity();
    if (identity?.deviceId) return identity.deviceId;
  } catch {}
  return "";
}

function saveRemoteIdentity(identity) {
  if (!safeStorage.isEncryptionAvailable()) throw new Error("Windows secure storage is unavailable");
  const payload = JSON.stringify(identity);
  fs.writeFileSync(REMOTE_IDENTITY_PATH, safeStorage.encryptString(payload), { mode: 0o600 });
}

function getRemoteIdentity() {
  try {
    if (!safeStorage.isEncryptionAvailable() || !fs.existsSync(REMOTE_IDENTITY_PATH)) return null;
    return JSON.parse(safeStorage.decryptString(fs.readFileSync(REMOTE_IDENTITY_PATH)));
  } catch { return null; }
}

function clearRemoteIdentity() {
  try { if (fs.existsSync(REMOTE_IDENTITY_PATH)) fs.unlinkSync(REMOTE_IDENTITY_PATH); } catch {}
}

function generateRemoteIdentity() {
  if (!safeStorage.isEncryptionAvailable()) throw new Error("Windows secure storage is unavailable");
  const pair = crypto.generateKeyPairSync("ed25519");
  const privateDer = pair.privateKey.export({ type: "pkcs8", format: "der" }).toString("base64");
  const publicDer = pair.publicKey.export({ type: "spki", format: "der" });
  // Ed25519 SPKI is a fixed 12-byte wrapper around the 32-byte raw key.
  const rawPublic = publicDer.subarray(-32).toString("base64url");
  return { privateKey: privateDer, publicKey: rawPublic, deviceId: "", serverPublicKey: "" };
}

function privateKeyObject(identity) {
  return crypto.createPrivateKey({ key: Buffer.from(identity.privateKey, "base64"), type: "pkcs8", format: "der" });
}

function signRemote(message, identity) {
  return crypto.sign(null, Buffer.from(message, "utf8"), privateKeyObject(identity)).toString("base64url");
}

function verifyRemote(message, signature, serverPublicKey) {
  try {
    return crypto.verify(null, Buffer.from(message, "utf8"), serverPublicKey, Buffer.from(String(signature), "base64url"));
  } catch { return false; }
}

function handshakeSigningInput(deviceId, nonce, timestamp) {
  return `ram-agent-v1|${deviceId}|${nonce}|${timestamp}`;
}

function commandSigningInput(env) {
  return canonicalRemote({
    v: env.v,
    type: "command",
    request_id: env.request_id,
    device_id: env.device_id,
    command: env.command,
    params: env.params ?? {},
    issued_at: env.issued_at,
    expires_at: env.expires_at,
    nonce: env.nonce,
  });
}

function safeServerPublicKey(identity) {
  if (!identity?.serverPublicKey) return null;
  try { return crypto.createPublicKey(identity.serverPublicKey); } catch { return null; }
}

function postJson(urlString, body) {
  return new Promise((resolve, reject) => {
    let u;
    try { u = new URL(urlString); } catch { return reject(new Error("Invalid relay URL")); }
    if (u.protocol !== "https:") return reject(new Error("Pairing requires HTTPS"));
    const https = require("https");
    const req = https.request({
      hostname: u.hostname,
      port: u.port || 443,
      path: u.pathname + u.search,
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      timeout: 10000,
    }, (res) => {
      let data = "";
      res.setEncoding("utf8");
      res.on("data", (chunk) => { data += chunk; });
      res.on("end", () => {
        let json = null;
        try { json = data ? JSON.parse(data) : null; } catch {}
        if (res.statusCode < 200 || res.statusCode >= 300) {
          reject(new Error(json?.error || json?.message || `Pairing failed (HTTP ${res.statusCode})`));
          return;
        }
        resolve(json);
      });
    });
    req.on("error", reject);
    req.on("timeout", () => { req.destroy(new Error("Pairing request timed out")); });
    req.end(JSON.stringify(body));
  });
}

function normalizeRelayOrigin(raw) {
  let value = String(raw || "").trim();
  if (!value) value = "https://aureon-collective.xyz";
  if (value.startsWith("wss://")) value = "https://" + value.slice(6);
  if (value.startsWith("ws://")) value = "http://" + value.slice(5);
  const u = new URL(value);
  if (u.protocol !== "https:") throw new Error("Remote access requires an HTTPS relay URL");
  u.pathname = u.pathname.replace(/\/+$/, "");
  u.search = "";
  u.hash = "";
  return u;
}

function relayWebSocketUrl(raw) {
  const u = normalizeRelayOrigin(raw);
  return `wss://${u.host}${u.pathname ? u.pathname : ""}/agent/ws`.replace(/\/\/agent\/ws$/, "/agent/ws");
}

async function getRobloxInstances() {
  if (process.platform !== "win32") return [];
  try {
    const { execFile } = require("child_process");
    const rows = await new Promise((resolve) => {
      const ps = `Get-CimInstance Win32_Process -Filter \"Name = 'RobloxPlayerBeta.exe'\" | ForEach-Object { \"$($_.ProcessId)|$($_.CreationDate)|$($_.CommandLine)\" }`;
      execFile("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", ps], { windowsHide: true, timeout: 8000 }, (_err, stdout) => resolve(String(stdout || "")));
    });
    const data = loadJson(ACCOUNTS_PATH, { accounts: {} });
    const accounts = Object.entries(data.accounts || {}).map(([name, cfg]) => ({ name, tracker: String(cfg?.browserTrackerId || ""), placeId: String(cfg?.placeId || "") }));
    return rows.split(/\r?\n/).map((line) => {
      const first = line.indexOf("|");
      const second = line.indexOf("|", first + 1);
      if (first <= 0 || second <= first) return null;
      const pid = line.slice(0, first).trim();
      const created = line.slice(first + 1, second).trim();
      const commandLine = line.slice(second + 1);
      const match = accounts.find((a) => a.tracker && new RegExp(`(?:^|\\s)-b\\s+${a.tracker}(?:\\s|$)`).test(commandLine));
      return { account: match?.name || "Roblox", place_id: match?.placeId || null, pid, started_at: Date.parse(created) || Date.now(), status: "running" };
    }).filter(Boolean);
  } catch { return []; }
}

async function remoteStateSnapshot() {
  const settings = { ...defaultSettings(), ...loadJson(SETTINGS_PATH, {}) };
  const data = loadJson(ACCOUNTS_PATH, { accounts: {} });
  const instances = await getRobloxInstances();
  const t = Date.now();
  const accounts = Object.entries(data.accounts || {}).map(([name, cfg]) => ({
    name,
    status: "unknown",
    place_id: /^\d{1,32}$/.test(String(cfg?.placeId || "")) ? String(cfg.placeId) : null,
    last_seen: t,
  }));
  return {
    accounts,
    instances,
    app_version: app.getVersion(),
    os_platform: `${process.platform}-${process.arch}`,
    timestamp: t,
    settings: {
      maxInstances: settings.maxInstances,
      launcherDelaySec: settings.launcherDelaySec,
      multiJoinGapSec: settings.multiJoinGapSec,
      onlineIntervalSec: settings.onlineIntervalSec,
      multiInstance: !!settings.multiInstance,
    },
  };
}

async function executeAgentCommand(command, params) {
  if (!REMOTE_ALLOWED_COMMANDS.has(command)) throw new Error("Command not allowed");
  const p = params || {};
  if (command === "GET_STATUS") return remoteStateSnapshot();
  if (command === "GET_ACCOUNTS") return (await remoteStateSnapshot()).accounts;
  if (command === "GET_INSTANCES") return (await remoteStateSnapshot()).instances;
  if (command === "GET_ACTIVITY") return { activity: [] };
  if (command === "SET_SETTING") {
    const allowed = new Set(["maxInstances", "launcherDelaySec", "multiJoinGapSec", "onlineIntervalSec", "multiInstance", "dashboardUrl"]);
    const key = String(p.key || "");
    if (!allowed.has(key)) throw new Error("Setting is not remotely configurable");
    const cur = { ...defaultSettings(), ...loadJson(SETTINGS_PATH, {}) };
    let value = String(p.value ?? "");
    if (["maxInstances", "launcherDelaySec", "multiJoinGapSec", "onlineIntervalSec"].includes(key)) {
      const n = Number(value);
      if (!Number.isFinite(n) || n < 0 || n > 3600) throw new Error("Invalid numeric setting");
      value = n;
    } else if (key === "multiInstance") {
      if (!/^(true|false)$/i.test(value)) throw new Error("multiInstance must be true or false");
      value = value.toLowerCase() === "true";
    } else if (key === "dashboardUrl") {
      if (value.length > 500) throw new Error("Dashboard URL is too long");
    }
    cur[key] = value;
    saveJson(SETTINGS_PATH, cur);
    return { ok: true, key, value };
  }
  if (command === "SET_ACCOUNT_CONFIG") {
    const name = String(p.account || "").trim();
    if (!name) throw new Error("Account name required");
    const data = loadJson(ACCOUNTS_PATH, { accounts: {} });
    if (!data.accounts?.[name]) throw new Error("Unknown account");
    data.accounts[name] = {
      ...data.accounts[name],
      placeId: String(p.place_id || data.accounts[name].placeId || "").trim(),
      autoRelaunch: !!p.auto_relaunch,
    };
    saveJson(ACCOUNTS_PATH, data);
    return { ok: true };
  }
  if (command === "LAUNCH_ACCOUNT") {
    const name = String(p.account || "").trim();
    const place = String(p.place_id || "").trim();
    if (!name || !/^\d{1,32}$/.test(place)) throw new Error("Account and numeric Place ID required");
    return joinGameInternal(name, place);
  }
  if (command === "MULTI_JOIN") {
    const accounts = Array.isArray(p.accounts) ? p.accounts.map((x) => String(x).trim()).filter(Boolean).slice(0, 15) : [];
    const place = String(p.place_id || "").trim();
    if (!accounts.length || !/^\d{1,32}$/.test(place)) throw new Error("Accounts and numeric Place ID required");
    const settings = { ...defaultSettings(), ...loadJson(SETTINGS_PATH, {}) };
    const max = Math.max(1, Number(settings.maxInstances || 5));
    const gap = Math.max(1, Number(settings.multiJoinGapSec || 6)) * 1000;
    const results = [];
    for (let i = 0; i < Math.min(accounts.length, max); i++) {
      try {
        if (await countRobloxProcesses() >= max) break;
        const result = await joinGameInternal(accounts[i], place);
        results.push({ account: accounts[i], ok: true, result });
      } catch (e) { results.push({ account: accounts[i], ok: false, error: String(e.message || e) }); }
      if (i < accounts.length - 1) await new Promise((r) => setTimeout(r, gap));
    }
    return { ok: true, results };
  }
  if (command === "ENABLE_MULTI_INSTANCE") return enableMultiInstanceInternal();
  if (command === "DISABLE_MULTI_INSTANCE") return disableMultiInstanceInternal();
  if (command === "CLOSE_ROBLOX") {
    if (p.scope === "all") return { ok: closeAllRobloxProcesses() };
    if (p.scope === "instance") {
      const pid = Number(p.instance_id);
      if (!Number.isSafeInteger(pid) || pid < 1) throw new Error("Invalid instance ID");
      const { execFile } = require("child_process");
      await new Promise((resolve) => execFile("taskkill.exe", ["/PID", String(pid), "/T", "/F"], { windowsHide: true, timeout: 8000 }, () => resolve()));
      return { ok: true, pid };
    }
    throw new Error("Invalid close scope");
  }
  if (command === "OPEN_ROBLOX_HOME") {
    const name = String(p.account || "").trim();
    if (!name) throw new Error("Account required");
    const state = loadSessionState(name);
    if (!state) throw new Error("No session");
    const { chromium } = require("playwright");
    const browser = await chromium.launch({ headless: false });
    const context = await browser.newContext({ storageState: state });
    await context.newPage().then((page) => page.goto("https://www.roblox.com/home"));
    return { ok: true };
  }
  throw new Error("Command not implemented");
}

function remoteSend(ws, obj) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}

let remoteStateTimer = null;
let remoteHeartbeatTimer = null;
let remoteReconnectTimer = null;
let remoteNonceCache = new Map();
let remotePairingInProgress = false;
let remoteLastError = '';

function stopRemoteBridge() {
  if (remoteStateTimer) clearInterval(remoteStateTimer);
  if (remoteHeartbeatTimer) clearInterval(remoteHeartbeatTimer);
  if (remoteReconnectTimer) clearTimeout(remoteReconnectTimer);
  remoteStateTimer = null;
  remoteHeartbeatTimer = null;
  remoteReconnectTimer = null;
  remotePairingInProgress = false;
  if (remoteBridge) {
    try { remoteBridge.removeAllListeners(); remoteBridge.close(); } catch {}
    remoteBridge = null;
  }
}

async function pushRemoteState(ws) {
  try {
    if (ws !== remoteBridge || ws.readyState !== WebSocket.OPEN) return;
    remoteSend(ws, { type: "state", ...(await remoteStateSnapshot()) });
  } catch {}
}

function startRemoteBridge() {
  stopRemoteBridge();
  const settings = { ...defaultSettings(), ...loadJson(SETTINGS_PATH, {}) };
  const remote = settings.remote || {};
  const identity = getRemoteIdentity();
  if (!remote.enabled || !identity?.deviceId || !identity?.privateKey || !identity?.serverPublicKey) return;
  let wsUrl;
  try { wsUrl = relayWebSocketUrl(remote.relayUrl); } catch { return; }
  const serverKey = safeServerPublicKey(identity);
  if (!serverKey) return;

  const ws = new WebSocket(wsUrl, { perMessageDeflate: false, handshakeTimeout: 10000 });
  remoteBridge = ws;
  let stage = "hello";
  let challenge = null;
  const seenCommands = new Map();

  ws.on("open", () => {
    remoteLastError = '';
    remoteSend(ws, {
      type: "hello",
      device_id: identity.deviceId,
      protocol_version: REMOTE_PROTOCOL_VERSION,
      app_version: app.getVersion(),
      os_platform: `${process.platform}-${process.arch}`,
    });
  });

  ws.on("message", async (raw) => {
    let msg;
    try { msg = JSON.parse(String(raw)); } catch { return; }
    if (!msg || typeof msg !== "object") return;

    if (stage === "hello") {
      if (msg.type !== "challenge" || typeof msg.nonce !== "string" || !Number.isFinite(msg.timestamp)) return;
      challenge = msg;
      const signature = signRemote(handshakeSigningInput(identity.deviceId, msg.nonce, msg.timestamp), identity);
      remoteSend(ws, { type: "proof", signature });
      stage = "proof";
      return;
    }
    if (stage === "proof") {
      if (msg.type !== "ready") return;
      stage = "ready";
      remoteLastError = '';
      await pushRemoteState(ws);
      remoteStateTimer = setInterval(() => pushRemoteState(ws), REMOTE_STATE_INTERVAL_MS);
      remoteHeartbeatTimer = setInterval(() => remoteSend(ws, { type: "heartbeat", app_version: app.getVersion(), os_platform: `${process.platform}-${process.arch}` }), REMOTE_HEARTBEAT_INTERVAL_MS);
      return;
    }
    if (stage !== "ready" || msg.type !== "command") return;

    const now = Date.now();
    if (typeof msg.request_id !== "string" || msg.device_id !== identity.deviceId) return;
    if (!Number.isFinite(msg.issued_at) || !Number.isFinite(msg.expires_at) || now > msg.expires_at || msg.issued_at > now + REMOTE_COMMAND_WINDOW_MS || msg.expires_at - msg.issued_at > 5 * 60 * 1000) return;
    const nonce = String(msg.nonce || "");
    if (!nonce || seenCommands.has(nonce)) return;
    if (!verifyRemote(commandSigningInput(msg), msg.signature, serverKey)) return;
    seenCommands.set(nonce, now);
    for (const [n, t] of seenCommands) if (now - t > 5 * 60 * 1000) seenCommands.delete(n);

    try {
      const data = await executeAgentCommand(msg.command, msg.params || {});
      remoteSend(ws, { v: REMOTE_PROTOCOL_VERSION, type: "result", request_id: msg.request_id, device_id: identity.deviceId, ok: true, data, error: null, completed_at: Date.now() });
      await pushRemoteState(ws);
    } catch (e) {
      remoteSend(ws, { v: REMOTE_PROTOCOL_VERSION, type: "result", request_id: msg.request_id, device_id: identity.deviceId, ok: false, data: null, error: String(e.message || e).slice(0, 500), completed_at: Date.now() });
    }
  });

  ws.on("close", () => {
    if (remoteBridge === ws) remoteBridge = null;
    if (remoteStateTimer) clearInterval(remoteStateTimer);
    if (remoteHeartbeatTimer) clearInterval(remoteHeartbeatTimer);
    remoteStateTimer = null;
    remoteHeartbeatTimer = null;
    const current = { ...defaultSettings(), ...loadJson(SETTINGS_PATH, {}) };
    if (current.remote?.enabled && getRemoteIdentity()?.deviceId) remoteReconnectTimer = setTimeout(startRemoteBridge, 5000);
  });
  ws.on("error", (err) => {
    remoteLastError = String(err?.message || err || "WebSocket connection failed").slice(0, 300);
  });
}

ipcMain.handle("remote-pair", async (_e, cfg) => {
  if (remotePairingInProgress) throw new Error("Pairing is already in progress");
  remotePairingInProgress = true;
  try {
    const relay = normalizeRelayOrigin(cfg?.relayUrl);
    const code = String(cfg?.code || "").trim().toUpperCase();
    const deviceName = String(cfg?.deviceName || "My PC").trim().slice(0, 48) || "My PC";
    if (!/^[A-Z0-9]{4}-?[A-Z0-9]{4}$/.test(code)) throw new Error("Enter the 8-character pairing code from the dashboard");
    const identity = generateRemoteIdentity();
    const response = await postJson(`${relay.origin}/api/agent/pair`, {
      code,
      device_name: deviceName,
      public_key: identity.publicKey,
      app_version: app.getVersion(),
      os_platform: `${process.platform}-${process.arch}`,
    });
    if (!response?.device_id || !response?.server_public_key) throw new Error("The relay returned an incomplete pairing response");
    const serverKey = crypto.createPublicKey(response.server_public_key);
    identity.deviceId = response.device_id;
    identity.serverPublicKey = response.server_public_key;
    saveRemoteIdentity(identity);
    const s = { ...defaultSettings(), ...loadJson(SETTINGS_PATH, {}) };
    s.remote = { ...(s.remote || {}), enabled: true, relayUrl: relay.origin, deviceName };
    saveJson(SETTINGS_PATH, s);
    stopRemoteBridge();
    startRemoteBridge();
    return { ok: true, deviceId: identity.deviceId, relayUrl: relay.origin, deviceName, secureStorage: safeStorage.isEncryptionAvailable(), connected: false, serverKeyValid: !!serverKey };
  } finally { remotePairingInProgress = false; }
});

ipcMain.handle("remote-get-config", () => {
  const s = { ...defaultSettings(), ...loadJson(SETTINGS_PATH, {}) };
  const identity = getRemoteIdentity();
  return {
    enabled: !!s.remote?.enabled,
    connected: !!(remoteBridge && remoteBridge.readyState === WebSocket.OPEN),
    relayUrl: s.remote?.relayUrl || "https://aureon-collective.xyz",
    deviceName: s.remote?.deviceName || "My PC",
    deviceId: identity?.deviceId || "",
    paired: !!(identity?.deviceId && identity?.privateKey && identity?.serverPublicKey),
    secureStorage: safeStorage.isEncryptionAvailable(),
    lastError: remoteLastError,
  };
});

ipcMain.handle("remote-save-config", (_e, cfg) => {
  const s = { ...defaultSettings(), ...loadJson(SETTINGS_PATH, {}) };
  const relayUrl = normalizeRelayOrigin(cfg?.relayUrl).origin;
  s.remote = { ...(s.remote || {}), enabled: !!cfg?.enabled, relayUrl, deviceName: String(cfg?.deviceName || "My PC").slice(0, 48) || "My PC" };
  saveJson(SETTINGS_PATH, s);
  if (s.remote.enabled) startRemoteBridge(); else stopRemoteBridge();
  const identity = getRemoteIdentity();
  return { enabled: s.remote.enabled, connected: !!(remoteBridge && remoteBridge.readyState === WebSocket.OPEN), relayUrl, deviceName: s.remote.deviceName, deviceId: identity?.deviceId || "", paired: !!identity?.deviceId, secureStorage: safeStorage.isEncryptionAvailable() };
});

ipcMain.handle("remote-unpair", () => {
  stopRemoteBridge();
  clearRemoteIdentity();
  const s = { ...defaultSettings(), ...loadJson(SETTINGS_PATH, {}) };
  s.remote = { ...(s.remote || {}), enabled: false };
  saveJson(SETTINGS_PATH, s);
  return true;
});

app.whenReady().then(async () => {
  // Pull accounts/sessions from older portable builds into AppData and encrypt them.
  try { migrateLegacyData(); } catch (e) { console.error(e); }
  try {
    // Also try importing if user dropped sessions next to this build
    if (fs.existsSync(LEGACY_SESSIONS) || fs.existsSync(path.join(LEGACY_ACCOUNTS_DIR, "accounts.json"))) {
      importFromLegacyRoot(ROOT);
    }
  } catch (e) { console.error(e); }
  createWindow();
  buildTray();
  const current = { ...defaultSettings(), ...loadJson(SETTINGS_PATH, {}) };
  try { app.setLoginItemSettings({ openAtLogin: !!current.startWithWindows }); } catch {}
  if (current.multiInstance) {
    try {
      const res = await enableMultiInstanceInternal();
      if (!res?.ok) {
        // Keep the preference, but mutex is not held (e.g. Roblox was still open).
        // UI will show enabled; user can toggle off/on after closing clients.
      }
    } catch {}
  }
  setTimeout(startRemoteBridge, 1200);
});
app.on("before-quit", () => { isQuitting = true; });
app.on("window-all-closed", () => {
  stopRemoteBridge();
  releaseMutexes();
  if (process.platform !== "darwin") app.quit();
});

// ── accounts / sessions ───────────────────────────────────────
function accountFile(name) {
  return sessionEncPath(name);
}

ipcMain.handle("list-accounts", () => {
  const data = loadJson(ACCOUNTS_PATH, { accounts: {} });
  return Object.keys(data.accounts || {}).sort();
});

ipcMain.handle("delete-account", (_e, name) => {
  const data = loadJson(ACCOUNTS_PATH, { accounts: {} });
  delete data.accounts[name];
  saveJson(ACCOUNTS_PATH, data);
  deleteSessionState(name);
  return true;
});

ipcMain.handle("get-settings", () => {
  return { ...defaultSettings(), ...loadJson(SETTINGS_PATH, {}) };
});

ipcMain.handle("save-settings", (_e, partial) => {
  // preserve known keys including new ones
  const cur = { ...defaultSettings(), ...loadJson(SETTINGS_PATH, {}) };
  Object.assign(cur, partial);
  saveJson(SETTINGS_PATH, cur);
  if (Object.prototype.hasOwnProperty.call(partial, "startWithWindows")) {
    try { app.setLoginItemSettings({ openAtLogin: !!cur.startWithWindows }); } catch {}
  }
  return cur;
});

ipcMain.handle("get-account-config", (_e, name) => {
  const data = loadJson(ACCOUNTS_PATH, { accounts: {} });
  return data.accounts[name] || { autoRelaunch: false, serverShuffle: false, placeId: "", relaunchDelaySec: 15 };
});

ipcMain.handle("save-account-config", (_e, name, cfg) => {
  const data = loadJson(ACCOUNTS_PATH, { accounts: {} });
  data.accounts = data.accounts || {};
  data.accounts[name] = { ...(data.accounts[name] || {}), ...cfg };
  saveJson(ACCOUNTS_PATH, data);
  return true;
});

ipcMain.handle("apply-relaunch-delay-all", (_e, delaySec) => {
  const delay = Math.max(1, Number(delaySec) || 15);
  const data = loadJson(ACCOUNTS_PATH, { accounts: {} });
  data.accounts = data.accounts || {};
  let count = 0;
  for (const name of Object.keys(data.accounts)) {
    data.accounts[name] = { ...(data.accounts[name] || {}), relaunchDelaySec: delay };
    count += 1;
  }
  saveJson(ACCOUNTS_PATH, data);
  return { ok: true, count, delay };
});

ipcMain.handle("apply-auto-relaunch-all", (_e, enabled) => {
  const on = !!enabled;
  const data = loadJson(ACCOUNTS_PATH, { accounts: {} });
  data.accounts = data.accounts || {};
  let count = 0;
  for (const name of Object.keys(data.accounts)) {
    data.accounts[name] = { ...(data.accounts[name] || {}), autoRelaunch: on };
    count += 1;
  }
  saveJson(ACCOUNTS_PATH, data);
  return { ok: true, count, enabled: on };
});

ipcMain.handle("export-accounts", () => {
  const data = loadJson(ACCOUNTS_PATH, { accounts: {} });
  const out = { version: APP_VERSION, exportedAt: new Date().toISOString(), accounts: {} };
  for (const [name, cfg] of Object.entries(data.accounts || {})) {
    out.accounts[name] = {
      autoRelaunch: !!cfg.autoRelaunch,
      serverShuffle: !!cfg.serverShuffle,
      placeId: String(cfg.placeId || ""),
      relaunchDelaySec: Math.max(1, Number(cfg.relaunchDelaySec) || 15),
    };
  }
  return out;
});

ipcMain.handle("import-accounts", (_e, payload) => {
  const incoming = payload?.accounts || {};
  const data = loadJson(ACCOUNTS_PATH, { accounts: {} });
  data.accounts = data.accounts || {};
  let added = 0;
  let updated = 0;
  for (const [name, cfg] of Object.entries(incoming)) {
    const clean = String(name || "").trim();
    if (!clean) continue;
    const exists = !!data.accounts[clean];
    data.accounts[clean] = {
      ...(data.accounts[clean] || {}),
      autoRelaunch: !!cfg.autoRelaunch,
      serverShuffle: !!cfg.serverShuffle,
      placeId: String(cfg.placeId || "").trim(),
      relaunchDelaySec: Math.max(1, Number(cfg.relaunchDelaySec) || 15),
    };
    if (exists) updated += 1; else added += 1;
  }
  saveJson(ACCOUNTS_PATH, data);
  return { ok: true, added, updated };
});


ipcMain.handle("get-data-paths", () => ({
  dataRoot: DATA_ROOT,
  sessions: SESSIONS,
  accounts: ACCOUNTS_DIR,
  encrypted: safeStorage.isEncryptionAvailable(),
  legacySessions: LEGACY_SESSIONS,
}));

ipcMain.handle("import-legacy-folder", async () => {
  const result = await dialog.showOpenDialog(mainWindow || undefined, {
    title: "Select older Roblox Account Manager folder",
    properties: ["openDirectory"],
  });
  if (result.canceled || !result.filePaths?.[0]) return { ok: false, cancelled: true };
  const report = importFromLegacyRoot(result.filePaths[0]);
  return { ok: true, ...report };
});

ipcMain.handle("get-saved-places", () => {
  const s = { ...defaultSettings(), ...loadJson(SETTINGS_PATH, {}) };
  return Array.isArray(s.savedPlaces) ? s.savedPlaces.slice(0, 50) : [];
});

ipcMain.handle("save-saved-places", (_e, places) => {
  const list = (Array.isArray(places) ? places : [])
    .map((p) => String(p || "").replace(/\D/g, ""))
    .filter((p) => p.length >= 5)
    .slice(0, 50);
  const cur = { ...defaultSettings(), ...loadJson(SETTINGS_PATH, {}) };
  cur.savedPlaces = [...new Set(list)];
  saveJson(SETTINGS_PATH, cur);
  return cur.savedPlaces;
});

ipcMain.handle("get-framerate-cap", () => readFramerateCap());

ipcMain.handle("set-framerate-cap", (_e, cap) => {
  const n = writeFramerateCap(cap);
  const cur = { ...defaultSettings(), ...loadJson(SETTINGS_PATH, {}) };
  cur.framerateCap = n;
  saveJson(SETTINGS_PATH, cur);
  return { ok: true, value: n, note: "Applies to Roblox clients started after this change. Restart existing clients to pick it up." };
});

ipcMain.handle("minimize-all-roblox", () => minimizeAllRobloxWindows());

ipcMain.handle("get-app-version", () => ({ version: APP_VERSION, updateUrl: UPDATE_CHECK_URL }));

ipcMain.handle("check-for-updates", async () => {
  // Non-nagging: just open the releases page so the user can decide.
  await shell.openExternal(UPDATE_CHECK_URL);
  return { ok: true, version: APP_VERSION };
});

ipcMain.handle("quit-app", () => {
  isQuitting = true;
  app.quit();
});

ipcMain.handle("show-main-window", () => {
  if (mainWindow) { mainWindow.show(); mainWindow.focus(); }
});

// ── manual login (headed browser) ─────────────────────────────
ipcMain.handle("add-account", async (_e, name) => {
  const cleanName = String(name || "").trim();
  if (!cleanName) throw new Error("Enter an account name.");
  if (cleanName.length > 64) throw new Error("Account name is too long.");

  const { chromium } = require("playwright");
  let browser;
  try {
    browser = await chromium.launch({
      headless: false,
          });
  } catch (e) {
    throw new Error("Could not open the Roblox login window. Run install.bat once so Playwright Chromium is installed.");
  }

  let context;
  try {
    context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
    const page = await context.newPage();
    await page.goto("https://www.roblox.com/login", { waitUntil: "domcontentloaded", timeout: 30000 });

    // Wait for a real Roblox authentication cookie instead of relying on fragile
    // page selectors. This keeps the account flow working when Roblox changes UI markup.
    const deadline = Date.now() + 10 * 60 * 1000;
    let authenticated = false;
    while (Date.now() < deadline) {
      const cookies = await context.cookies("https://www.roblox.com");
      authenticated = cookies.some((c) => c.name === ".ROBLOSECURITY" && c.value);
      if (authenticated) break;
      await page.waitForTimeout(1000);
    }

    if (!authenticated) throw new Error("Login timed out. Finish the Roblox login in the opened window and try again.");

    const state = await context.storageState();
    saveSessionState(cleanName, state);

    const data = loadJson(ACCOUNTS_PATH, { accounts: {} });
    data.accounts = data.accounts || {};
    data.accounts[cleanName] = data.accounts[cleanName] || { autoRelaunch: false, serverShuffle: false, placeId: "", relaunchDelaySec: 15 };
    saveJson(ACCOUNTS_PATH, data);
    return true;
  } finally {
    try { if (context) await context.close(); } catch {}
    try { if (browser) await browser.close(); } catch {}
  }
});

// ── join game ─────────────────────────────────────────────────
function extractPlaceId(raw) {
  const s = String(raw).trim();
  const m = s.match(/(?:\/games\/|placeId=)(\d+)/i) || s.match(/(\d{5,})/);
  if (!m) throw new Error("Invalid place ID");
  return m[1];
}

function getRobloxCookieFromState(stateOrName) {
  const state = typeof stateOrName === "string" ? loadSessionState(stateOrName) : stateOrName;
  const cookie = state?.cookies?.find((c) => c.domain?.endsWith("roblox.com") && c.name === ".ROBLOSECURITY" && c.value);
  if (!cookie?.value) throw new Error("Saved Roblox session is missing or expired.");
  return cookie.value;
}

async function requestAuthTicket(stateOrName) {
  // Roblox's current ticket flow expects a JSON POST with a browser-like
  // referer/content-type.  Asking /v2/logout for the CSRF token first also
  // avoids treating a 415 response from the ticket endpoint as an expired
  // account.
  const state = typeof stateOrName === "string" ? loadSessionState(stateOrName) : stateOrName;
  if (!state) throw new Error("No session for this account");
  const { request } = require("playwright");
  let api;
  try {
    api = await request.newContext({
      storageState: state,
      extraHTTPHeaders: {
        "Origin": "https://www.roblox.com",
        "Referer": "https://www.roblox.com/camel",
        "Accept": "application/json, text/plain, */*",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/153.0.0.0 Safari/537.36",
      },
    });

    const csrfResponse = await api.post("https://auth.roblox.com/v2/logout", {
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
      },
      data: {},
    });
    const csrf = csrfResponse.headers()["x-csrf-token"];
    if (!csrf) {
      if (csrfResponse.status() === 401) throw new Error("This Roblox login has expired. Re-add the account.");
      throw new Error(`Roblox did not provide a CSRF token (HTTP ${csrfResponse.status()}).`);
    }

    const ticketResponse = await api.post("https://auth.roblox.com/v1/authentication-ticket/", {
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-CSRF-TOKEN": csrf,
        "RBXAuthenticationNegotiation": "1",
        "Referer": "https://www.roblox.com/camel",
      },
      data: {},
    });

    const ticket = ticketResponse.headers()["rbx-authentication-ticket"];
    if (!ticket) {
      if (ticketResponse.status() === 401) throw new Error("This Roblox login has expired. Re-add the account.");
      if (ticketResponse.status() === 403) throw new Error("Roblox refused the launch ticket request. Try removing and re-adding this account.");
      if (ticketResponse.status() === 415) throw new Error("Roblox rejected the launch request format (HTTP 415). The account session is fine, but Roblox changed the ticket endpoint behavior.");
      throw new Error(`Roblox did not return a launch ticket (HTTP ${ticketResponse.status()}).`);
    }
    return String(ticket);
  } finally {
    try { await api?.dispose(); } catch {}
  }
}


async function launchRobloxDirect(accountName, placeId, jobId = "") {
  const state = loadSessionState(accountName);
  if (!state) throw new Error("No session for " + accountName);

  const ticket = await requestAuthTicket(state);
  const data = loadJson(ACCOUNTS_PATH, { accounts: {} });
  const existing = data.accounts?.[accountName] || {};
  // Keep a stable per-account tracker, but never reuse one already assigned to another account.
  const used = new Set(
    Object.entries(data.accounts || {})
      .filter(([n]) => n !== accountName)
      .map(([, cfg]) => String(cfg?.browserTrackerId || ""))
      .filter(Boolean)
  );
  let browserTrackerId = String(existing.browserTrackerId || "");
  if (!browserTrackerId || used.has(browserTrackerId)) {
    do {
      browserTrackerId = String(Math.floor(Math.random() * 900000000) + 100000000);
    } while (used.has(browserTrackerId));
  }
  const launcherBase = jobId ? "https://www.roblox.com/Game/PlaceLauncher.ashx" : "https://assetgame.roblox.com/game/PlaceLauncher.ashx";
  const launcherUrl = `${launcherBase}?request=${jobId ? "RequestGameJob" : "RequestGame"}&browserTrackerId=${browserTrackerId}&placeId=${placeId}&isPlayTogetherGame=false${jobId ? `&gameId=${encodeURIComponent(jobId)}&joinAttemptOrigin=AccountManager` : ""}`;
  const launchUri =
    "roblox-player:1+launchmode:play" +
    "+gameinfo:" + ticket +
    "+launchtime:" + Date.now() +
    "+placelauncherurl:" + encodeURIComponent(launcherUrl) +
    "+browsertrackerid:" + browserTrackerId +
    "+robloxLocale:en_us+gameLocale:en_us+LaunchExp:InApp";

  await shell.openExternal(launchUri);
  return { placeId, jobId: jobId || "", launched: true, browserTrackerId };
}

async function joinGameInternal(accountName, placeRaw, jobId = "") {
  const placeId = extractPlaceId(placeRaw);
  const result = await launchRobloxDirect(accountName, placeId, jobId);
  const data = loadJson(ACCOUNTS_PATH, { accounts: {} });
  data.accounts = data.accounts || {};
  data.accounts[accountName] = { ...(data.accounts[accountName] || {}), placeId, lastJobId: jobId || "", lastLaunchAt: Date.now(), browserTrackerId: result.browserTrackerId || data.accounts[accountName]?.browserTrackerId || "" };
  saveJson(ACCOUNTS_PATH, data);
  return result;
}

ipcMain.handle("join-game", (_e, accountName, placeRaw, jobId) => joinGameInternal(accountName, placeRaw, jobId));

async function closeAccountProcess(accountName) {
  const data = loadJson(ACCOUNTS_PATH, { accounts: {} });
  const tracker = String(data.accounts?.[accountName]?.browserTrackerId || "");
  if (!tracker) return false;
  const { execFile } = require("child_process");
  const script = `Get-CimInstance Win32_Process -Filter \"Name = 'RobloxPlayerBeta.exe'\" | ForEach-Object { if ($_.CommandLine -match '-b\\s+${tracker}\\b') { Stop-Process -Id $_.ProcessId -Force } }`;
  return new Promise((resolve) => execFile("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", script], { windowsHide: true }, () => resolve(true)));
}

ipcMain.handle("close-account", (_e, accountName) => closeAccountProcess(accountName));

function pingHost(host) {
  return new Promise((resolve) => {
    execFile(process.platform === "win32" ? "ping" : "ping", process.platform === "win32" ? ["-n", "1", "-w", "800", host] : ["-c", "1", "-W", "1", host], { timeout: 1500 }, (err, stdout) => {
      if (err) return resolve(null);
      const m = String(stdout).match(/(?:Average|Moyenne|avg)[^=]*[=]\s*(\d+)ms|[<]?(\d+(?:\.\d+)?)\s*ms/i);
      resolve(m ? Math.round(Number(m[1] || m[2])) : null);
    });
  });
}

async function getServerList(accountName, placeRaw) {
  const placeId = extractPlaceId(placeRaw);
  const state = loadSessionState(accountName);
  if (!state) throw new Error("No session for " + accountName);
  const { request } = require("playwright");
  const api = await request.newContext({ storageState: state, extraHTTPHeaders: { "User-Agent": "Mozilla/5.0", "Accept": "application/json" } });
  try {
    const res = await api.get(`https://games.roblox.com/v1/games/${placeId}/servers/Public?sortOrder=Asc&limit=100`);
    if (!res.ok()) throw new Error(`Could not load servers (HTTP ${res.status()}).`);
    const body = await res.json();
    return (body.data || []).filter(s => s && s.id && s.playing < s.maxPlayers).map(s => ({ id: s.id, playing: s.playing, maxPlayers: s.maxPlayers, ping: null, region: "Unknown", regionLoaded: false }));
  } finally { await api.dispose(); }
}

async function enrichServers(accountName, placeId, servers) {
  const state = loadSessionState(accountName);
  if (!state) throw new Error("No session for " + accountName);
  const { request } = require("playwright");
  const api = await request.newContext({ storageState: state, extraHTTPHeaders: { "User-Agent": "Mozilla/5.0", "Accept": "application/json" } });
  const out = [];
  try {
    for (const server of servers.slice(0, 20)) {
      try {
        const res = await api.post("https://gamejoin.roblox.com/v1/join-game-instance", { headers: { "Content-Type": "application/json" }, data: { gameId: server.id, placeId: Number(placeId) } });
        if (res.ok()) {
          const j = await res.json();
          const ip = j?.joinScript?.MachineAddress || "";
          if (ip) {
            const geo = await (async () => {
              try { const r = await api.get(`https://ipapi.co/${ip}/json/`); return r.ok() ? await r.json() : {}; } catch { return {}; }
            })();
            server.region = geo?.region || geo?.city || geo?.country_name || "Unknown";
            server.country = geo?.country_name || "";
            server.ping = await pingHost(ip);
            server.regionLoaded = true;
          }
        }
      } catch {}
      out.push(server);
    }
    return out;
  } finally { await api.dispose(); }
}

ipcMain.handle("get-servers", async (_e, accountName, placeRaw) => {
  const servers = await getServerList(accountName, placeRaw);
  return enrichServers(accountName, extractPlaceId(placeRaw), servers);
});

ipcMain.handle("shuffle-server", async (_e, accountName, placeRaw, options = {}) => {
  const placeId = extractPlaceId(placeRaw);
  let servers = await getServerList(accountName, placeId);
  servers = await enrichServers(accountName, placeId, servers);
  const data = loadJson(ACCOUNTS_PATH, { accounts: {} });
  const used = new Set(Object.values(data.accounts || {}).map(a => a?.lastJobId).filter(Boolean));
  const filtered = servers.filter(s => !used.has(s.id) && s.playing < s.maxPlayers);
  const minPing = Number(options.minPing || 0);
  const maxPing = Number(options.maxPing || 9999);
  const region = String(options.region || "Any");
  const candidates = filtered.filter(s => {
    if (s.ping != null && (s.ping < minPing || s.ping > maxPing)) return false;
    if (region !== "Any" && s.region !== "Unknown" && !s.region.toLowerCase().includes(region.toLowerCase())) return false;
    return true;
  });
  if (!candidates.length) throw new Error("No matching server found. Try widening the ping/region filters.");
  const chosen = candidates[Math.floor(Math.random() * candidates.length)];
  return { ...chosen, placeId };
});

ipcMain.handle("open-home", async (_e, accountName) => {
  const state = loadSessionState(accountName);
  if (!state) throw new Error("No session");
  const { chromium } = require("playwright");
  const browser = await chromium.launch({ headless: false });
  const context = await browser.newContext({ storageState: state });
  const page = await context.newPage();
  await page.goto("https://www.roblox.com/home");
  return true;
});

let shuffleTimer = null;
async function startShuffleScheduler() {
  if (shuffleTimer) clearInterval(shuffleTimer);
  const settings = loadJson(SETTINGS_PATH, defaultSettings());
  const hours = Math.max(0.25, Number(settings.serverShuffle?.intervalHours || 2));
  if (!settings.serverShuffle?.enabled) return;
  shuffleTimer = setInterval(async () => {
    const data = loadJson(ACCOUNTS_PATH, { accounts: {} });
    const all = data.accounts || {};
    for (const [name, cfg] of Object.entries(all)) {
      if (!cfg?.serverShuffle || !cfg.placeId) continue;
      try {
        const chosen = await (async () => {
          const servers = await enrichServers(name, cfg.placeId, await getServerList(name, cfg.placeId));
          const used = new Set(Object.values(all).map(a => a?.lastJobId).filter(Boolean));
          const opts = settings.serverShuffle || {};
          const candidates = servers.filter(s => !used.has(s.id) && s.playing < s.maxPlayers);
          const region = String(opts.region || "Any");
          const min = Number(opts.minPing || 0), max = Number(opts.maxPing || 9999);
          const filtered = candidates.filter(s => (region === "Any" || s.region === "Unknown" || s.region.toLowerCase().includes(region.toLowerCase())) && (s.ping == null || (s.ping >= min && s.ping <= max)));
          return (filtered.length ? filtered : candidates)[Math.floor(Math.random() * (filtered.length ? filtered : candidates).length)];
        })();
        if (!chosen) continue;
        await closeAccountProcess(name);
        await new Promise(r => setTimeout(r, 1000));
        await joinGameInternal(name, cfg.placeId, chosen.id);
      } catch {}
    }
  }, hours * 60 * 60 * 1000);
}

ipcMain.handle("server-shuffle-settings", async (_e, partial) => {
  const settings = loadJson(SETTINGS_PATH, defaultSettings());
  settings.serverShuffle = { ...(settings.serverShuffle || {}), ...partial };
  saveJson(SETTINGS_PATH, settings);
  await startShuffleScheduler();
  return settings.serverShuffle;
});

// ── online status (fast) ──────────────────────────────────────
async function checkOnlineInternal(names) {
  const results = {};
  const https = require("https");

  async function request(method, url, headers, body) {
    return new Promise((resolve, reject) => {
      const u = new URL(url);
      const req = https.request(
        {
          hostname: u.hostname,
          path: u.pathname + u.search,
          method,
          headers: { ...headers, "Content-Type": "application/json", "User-Agent": "RobloxLauncher/2.0" },
        },
        (res) => {
          let data = "";
          res.on("data", (c) => (data += c));
          res.on("end", () => {
            try {
              resolve({ status: res.statusCode, json: data ? JSON.parse(data) : null });
            } catch {
              resolve({ status: res.statusCode, json: null });
            }
          });
        }
      );
      req.on("error", reject);
      req.setTimeout(8000, () => {
        req.destroy();
        reject(new Error("timeout"));
      });
      if (body) req.write(body);
      req.end();
    });
  }

  function cookiesFromState(name) {
    try {
      const state = loadSessionState(name);
      if (!state) return "";
      return (state.cookies || [])
        .map((c) => c.name + "=" + c.value)
        .join("; ");
    } catch {
      return "";
    }
  }

  await Promise.all(
    (names || []).map(async (name) => {
      results[name] = { online: null, error: null, userId: null };
      let state;
      try { state = loadSessionState(name); } catch { state = null; }
      if (!state) {
        results[name].error = "no session";
        return;
      }
      const cookie = cookiesFromState(name);
      if (!cookie) {
        results[name].error = "no cookies";
        return;
      }
      try {
        const auth = await request("GET", "https://users.roblox.com/v1/users/authenticated", {
          Cookie: cookie,
        });
        if (auth.status !== 200 || !auth.json || !auth.json.id) {
          results[name].error = "session expired";
          results[name].online = false;
          return;
        }
        const userId = auth.json.id;
        results[name].userId = userId;
        const pres = await request(
          "POST",
          "https://presence.roblox.com/v1/presence/users",
          { Cookie: cookie },
          JSON.stringify({ userIds: [userId] })
        );
        if (pres.status === 200 && pres.json && pres.json.userPresences && pres.json.userPresences[0]) {
          const t = pres.json.userPresences[0].userPresenceType;
          // 0 offline, 1 online, 2 in-game, 3 studio
          results[name].online = t === 1 || t === 2 || t === 3;
          results[name].lastLocation = pres.json.userPresences[0].lastLocation || null;
        } else {
          results[name].online = false;
        }
      } catch (e) {
        results[name].error = String(e.message || e);
      }
    })
  );

  return results;
}
ipcMain.handle("check-online", (_e, names) => checkOnlineInternal(names));

// ── multi-instance (Windows mutex via PowerShell) ─────────────
// Roblox uses named mutexes so only one client can run. We create and hold
// ROBLOX_singletonMutex / ROBLOX_singletonEvent first so new clients skip the
// singleton check. Existing Roblox processes already own those mutexes, so the
// user must close all Roblox clients before enabling.
function releaseMutexes() {
  for (const c of mutexHandles) {
    try { if (c && !c.killed) c.kill(); } catch {}
  }
  mutexHandles = [];
}

async function enableMultiInstanceInternal() {
  if (process.platform !== "win32") return { ok: false, message: "Windows only" };

  // Refuse while Roblox is still running — mutex is already held by the client.
  try {
    const n = await countRobloxProcesses();
    if (n > 0) {
      return {
        ok: false,
        message: `Close all Roblox clients before enabling multi-instance (${n} still running).`,
      };
    }
  } catch {}

  // Drop any previous holder we started.
  releaseMutexes();

  const { spawn } = require("child_process");
  // Create mutexes with initial ownership and keep this process alive so they
  // stay held. Do not try to OpenExisting/Dispose Roblox-owned mutexes — that
  // does not transfer ownership and leaves multi-instance broken.
  const ps = `
$ErrorActionPreference = 'Stop'
try {
  # Roblox uses a Mutex for the legacy singletonMutex name and an Event for
  # the current singletonEvent name. They are different kernel object types;
  # creating singletonEvent as a Mutex makes Roblox fail its startup check.
  $m1 = New-Object System.Threading.Mutex($true, 'ROBLOX_singletonMutex')
  $m2 = New-Object System.Threading.EventWaitHandle($false, [System.Threading.EventResetMode]::ManualReset, 'ROBLOX_singletonEvent')
  [Console]::Out.WriteLine('OK')
  [Console]::Out.Flush()
  while ($true) { Start-Sleep -Seconds 60 }
} catch {
  [Console]::Error.WriteLine($_.Exception.Message)
  exit 1
}
`;
  try {
    const child = spawn(
      "powershell.exe",
      ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
      { detached: true, stdio: ["ignore", "pipe", "pipe"], windowsHide: true }
    );
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (d) => { stdout += d.toString(); });
    child.stderr.on("data", (d) => { stderr += d.toString(); });
    mutexHandles.push(child);
    child.unref();

    // Wait briefly for the OK line or process exit.
    const ok = await new Promise((resolve) => {
      const timer = setTimeout(() => resolve(stdout.includes("OK")), 1500);
      child.once("exit", (code) => {
        clearTimeout(timer);
        resolve(code === 0 && stdout.includes("OK"));
      });
      child.stdout.once("data", () => {
        if (stdout.includes("OK")) {
          clearTimeout(timer);
          resolve(true);
        }
      });
    });

    if (!ok) {
      releaseMutexes();
      const detail = (stderr || stdout || "mutex create failed").trim().slice(0, 200);
      return { ok: false, message: "Could not hold Roblox mutex. Close all Roblox clients and try again. " + detail };
    }
    return { ok: true, message: "Multi-instance active – keep this app open" };
  } catch (e) {
    releaseMutexes();
    return { ok: false, message: String(e.message || e) };
  }
}
async function disableMultiInstanceInternal() {
  releaseMutexes();
  return { ok: true, message: "Disabled" };
}
ipcMain.handle("multi-instance-enable", enableMultiInstanceInternal);
ipcMain.handle("multi-instance-disable", disableMultiInstanceInternal);

async function countRobloxProcesses() {
  try {
    const { execSync } = require("child_process");
    if (process.platform === "win32") {
      const out = execSync('tasklist /FI "IMAGENAME eq RobloxPlayerBeta.exe" /NH', { encoding: "utf8" });
      return out.split(/\r?\n/).filter((l) => /RobloxPlayerBeta/i.test(l)).length;
    }
    return 0;
  } catch { return 0; }
}
ipcMain.handle("count-roblox", countRobloxProcesses);
ipcMain.handle("account-process-running", async (_e, name) => {
  const data = loadJson(ACCOUNTS_PATH, { accounts: {} });
  const tracker = String(data.accounts?.[name]?.browserTrackerId || "");
  if (!tracker || process.platform !== "win32") return false;
  const { execFile } = require("child_process");
  const script = `$found = $false; Get-CimInstance Win32_Process -Filter "Name = 'RobloxPlayerBeta.exe'" | ForEach-Object { if ($_.CommandLine -match '-b\\s+${tracker}\\b') { $found = $true } }; if ($found) { 'YES' } else { 'NO' }`;
  return new Promise((resolve) => execFile("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", script], { windowsHide: true }, (_err, stdout) => resolve(String(stdout).trim() === "YES")));
});


function closeAllRobloxProcesses() {
  try {
    const { execSync } = require("child_process");
    if (process.platform === "win32") {
      try { execSync("taskkill /F /IM RobloxPlayerBeta.exe /T", { stdio: "ignore" }); } catch {}
      try { execSync("taskkill /F /IM RobloxPlayerLauncher.exe /T", { stdio: "ignore" }); } catch {}
    }
    return true;
  } catch { return false; }
}
ipcMain.handle("close-all-roblox", closeAllRobloxProcesses);

ipcMain.handle("open-external", (_e, url) => {
  shell.openExternal(url);
});
