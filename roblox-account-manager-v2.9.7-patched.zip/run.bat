@echo off
cd /d "%~dp0"
if not exist "node_modules\electron" (
  echo Run install.bat first.
  pause
  exit /b 1
)

REM Launch Electron without a visible Command Prompt window.
set ELECTRON_NO_ATTACH_CONSOLE=1
if exist "node_modules\electron\dist\electron.exe" (
  start "" "node_modules\electron\dist\electron.exe" .
) else (
  start "" /B cmd /c "npm start >nul 2>&1"
)
exit /b 0
