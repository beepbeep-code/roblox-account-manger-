# Remote control protocol — v2.9.7

The desktop application is the security anchor for remote control.

## Connection model

- The desktop app makes an **outbound** WebSocket connection.
- It never opens a listening HTTP server or exposes a local port.
- Production transport is `wss://<dashboard-host>/agent/ws`.
- The website sends commands through the backend relay; the phone/browser never connects directly to the PC.

## Pairing

1. Sign in to the web dashboard.
2. Open **Remote Control → Connect Desktop → Generate pairing code**.
3. On the desktop app open **Remote access** and enter the one-time code.
4. The desktop generates an Ed25519 keypair locally.
5. The desktop sends only the public key to `POST /api/agent/pair`.
6. The server returns a device ID and its signing public key.
7. The private device key is encrypted using Electron/Windows secure storage and remains on the PC.

The pairing code is single-use and short-lived. Revoking the device on the website invalidates the stored server-side device record.

## Handshake

```text
agent -> { type: "hello", device_id, protocol_version, app_version, os_platform }
server -> { type: "challenge", nonce, timestamp }
agent -> { type: "proof", signature }
server -> { type: "ready" }
```

The proof is an Ed25519 signature over:

```text
ram-agent-v1|device_id|nonce|timestamp
```

## Commands

Server-to-agent commands are Ed25519-signed envelopes. The desktop verifies:

- protocol version
- device ID
- issued/expiry timestamps
- short TTL
- nonce replay protection
- server signature
- explicit command allowlist

There is no remote shell, arbitrary command execution, file transfer, PowerShell passthrough, or custom script mechanism.

Supported commands are limited to account/status reads, supported settings, account launch, multi-join, multi-instance toggling, Roblox closing, and opening Roblox home.

## State

The desktop periodically pushes sanitized state containing account names/status/place IDs and running Roblox instance metadata. Roblox cookies, session files, private keys, and other credentials are never included.
