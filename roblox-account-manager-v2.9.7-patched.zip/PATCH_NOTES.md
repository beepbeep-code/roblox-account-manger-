# v2.9.7 patch notes

- Fixed Roblox multi-instance singleton object types:
  - `ROBLOX_singletonMutex` is created as a Mutex.
  - `ROBLOX_singletonEvent` is created as an EventWaitHandle.
- Fixed the internal app version mismatch (`2.9.6` -> `2.9.7`).
- Remote WSS errors are now surfaced in the Remote access status instead of being silently swallowed.

Note: the remote pairing API/server is not included in this desktop project, so the relay-side `/api/agent/pair` and `/agent/ws` implementation could not be verified from this archive.
