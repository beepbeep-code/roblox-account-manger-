# Roblox Launcher 2 (Electron)

Modern desktop app – **not Python**.

## Windows – easiest install

1. Install **Node.js LTS** from https://nodejs.org (includes npm)
2. Unzip this folder
3. Double-click **`install.bat`**
4. Double-click **`run.bat`**

## What you get
- Fast online status (default every **12 seconds**, parallel checks)
- Clean dark UI with page fade animations
- Multi-account sessions via Playwright
- Join by Place ID (`/games/start?placeId=…`)
- Multi-instance (Windows singleton mutex hold)
- Multi-join, close-all, settings, dashboard link

## Commands
```bash
npm install
npx playwright install chromium
npm start
```

## Secure remote access
The desktop app includes an optional outbound remote bridge for an existing web dashboard.

Security model:
- The desktop app does **not** open a public HTTP server or listen on an internet-facing port.
- Internet relay connections use WSS (TLS).
- Pairing uses a short-lived, single-use dashboard code.
- The desktop generates an Ed25519 identity locally; the relay stores only the public key.
- The desktop private key and pinned server public key are stored with Electron's OS-backed `safeStorage` encryption on Windows.
- Commands are server-signed, expire quickly, and use nonce replay protection.
- Remote commands are allowlisted; there is **no remote shell, PowerShell, arbitrary executable, or arbitrary filesystem command**.
- Roblox cookies/session files are never sent to the relay. The desktop performs Roblox checks and launches locally.
- Disconnecting/revoking the device on the website invalidates the stored pairing.

### Web dashboard requirement
The matching dashboard uses the same Ed25519 pairing/agent protocol. **Do not create, copy, or place a master key in browser JavaScript or client-side storage.**

The desktop protocol is documented in `REMOTE_PROTOCOL.md`.


## v2.3 changes
- Updated Roblox authentication-ticket flow to use the current CSRF + JSON request pattern.
- Direct Roblox protocol launch remains enabled so Windows does not need to open a browser confirmation.
- Added local Saved Games: save up to 50 Place IDs, select them from the dashboard, and remove them when needed.
- Kept the simple defaults: Multi Roblox on, 15 max instances, 20s launcher delay, 15s multi-join gap, 12s online check.

The project takes inspiration from the feature set of ic3w0lf22's archived Roblox Account Manager, especially direct launching, saved places, and multi-account workflows, but the implementation here is separate.

## v2.8 changes
- **Auto-Relaunch background**: keeps monitoring while the window is minimized or unfocused. Only real process exit / offline status triggers a relaunch (unfocus alone does nothing).
- Default **relaunch delay is 15 seconds**; per-account overrides still work.
- **Apply delay to all accounts** button on the Accounts page.
- **Silent launch**: `run.bat` starts Electron without a visible Command Prompt.
- Subtle **Discord** link in the sidebar bottom area → https://discord.gg/TR8RvUf67N

## v2.9 changes
- Per-account live status (Launching / Relaunching / Queued / Error) with last error line
- Max relaunch attempts + cooldown after the cap (Settings)
- Stop / Enable Auto-relaunch for all accounts
- System tray with close-to-tray, Open, Pause all relaunch, Close all Roblox, Quit
- Global saved Place IDs
- Visible launch queue while multi-launching
- Network note (system network only; cookies stay local)
- Export / import account config (no cookies)
- Non-nagging "Check for updates" (opens releases page)
- Minimize all Roblox windows (reduces GPU when minimized)
- FPS cap via %LOCALAPPDATA%\Roblox\GlobalBasicSettings_13.xml FramerateCap

## Secure remote dashboard pairing (v2.9.7)

The Remote access page now uses the website's Ed25519 pairing protocol. Do **not** create or copy a master key for remote access.

1. Open the web dashboard and generate a one-time pairing code.
2. In the desktop app open **Remote access**.
3. Confirm the relay URL and device name, enter the code, and click **Pair this PC**.
4. Leave the desktop app running. It maintains an outbound WSS connection to the relay.

The private Ed25519 identity is protected with Windows secure storage. The server stores only the public key and sanitized device state.
