@echo off
title Roblox Launcher - Install
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
  echo Node.js not found. Install LTS from https://nodejs.org
  echo Enable "Add to PATH" during install.
  pause
  exit /b 1
)
echo Installing packages...
call npm install
if errorlevel 1 (
  echo npm install failed
  pause
  exit /b 1
)
echo Installing Chromium for Playwright...
call npx playwright install chromium
echo.
echo Done. Double-click run.bat to start.
pause
